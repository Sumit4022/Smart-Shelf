<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>Issue Book — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">
  <h2>Issue Book</h2>

  <c:if test="${param.success != null}">
    <div class="alert alert-success">✅ ${param.success}</div>
  </c:if>
  <c:if test="${param.error != null}">
    <div class="alert alert-error">⚡ Trigger fired: ${param.error}</div>
  </c:if>

  <div class="card" style="max-width:520px">
    <form method="post" action="issue">

      <div class="form-group">
        <label>Member</label>
        <select name="memberId" required>
          <option value="">-- Select Member --</option>
          <c:forEach var="m" items="${members}">
            <option value="${m.Member_Id}">${m.Name}</option>
          </c:forEach>
        </select>
      </div>

      <div class="form-group">
        <label>Book</label>
        <select name="bookId" required>
          <option value="">-- Select Book --</option>
          <c:forEach var="b" items="${books}">
            <option value="${b.Book_Id}">${b.Title} (${b.Quantity} available)</option>
          </c:forEach>
        </select>
      </div>

      <div class="form-group">
        <label>Librarian</label>
        <select name="librarianId" required>
          <option value="">-- Select Librarian --</option>
          <c:forEach var="l" items="${librarians}">
            <option value="${l.Librarian_Id}">${l.Name}</option>
          </c:forEach>
        </select>
      </div>

      <div class="trigger-info">
        ⚡ Active triggers: check_max_books · check_book_availability · reduce_quantity_on_issue
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%">
        ⬆️ Issue Book
      </button>
    </form>
  </div>
</div>
</body>
</html>
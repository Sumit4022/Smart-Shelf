<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>Trigger Demo — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .demo-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 24px;
    }
    .trigger-card {
      background: #13161d;
      border: 1px solid #252a36;
      border-radius: 12px;
      padding: 24px;
      border-left: 4px solid #e8c87a;
    }
    .trigger-card.red   { border-left-color: #e87a7a; }
    .trigger-card.blue  { border-left-color: #7ab8e8; }
    .trigger-card.green { border-left-color: #8be8a4; }
    .trigger-card h3 {
      font-family: monospace;
      font-size: 13px;
      color: #e8c87a;
      margin-bottom: 6px;
    }
    .trigger-card.red h3   { color: #e87a7a; }
    .trigger-card.blue h3  { color: #7ab8e8; }
    .trigger-card.green h3 { color: #8be8a4; }
    .trigger-card p {
      font-size: 12px;
      color: #6b7280;
      margin-bottom: 16px;
      line-height: 1.6;
    }
    .trigger-card .timing {
      display: inline-block;
      font-family: monospace;
      font-size: 10px;
      padding: 2px 8px;
      border-radius: 4px;
      background: rgba(232,200,122,0.1);
      color: #e8c87a;
      border: 1px solid rgba(232,200,122,0.2);
      margin-bottom: 12px;
    }
    .trigger-card.red .timing {
      background: rgba(232,122,122,0.1);
      color: #e87a7a;
      border-color: rgba(232,122,122,0.2);
    }
    .trigger-card.blue .timing {
      background: rgba(122,184,232,0.1);
      color: #7ab8e8;
      border-color: rgba(122,184,232,0.2);
    }
    .trigger-card.green .timing {
      background: rgba(139,232,164,0.1);
      color: #8be8a4;
      border-color: rgba(139,232,164,0.2);
    }
    .result-box {
      padding: 16px 20px;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 500;
      margin-bottom: 24px;
      line-height: 1.6;
      display: flex;
      align-items: flex-start;
      gap: 12px;
    }
    .result-success {
      background: rgba(139,232,164,0.1);
      border: 1px solid rgba(139,232,164,0.3);
      color: #8be8a4;
    }
    .result-fail {
      background: rgba(232,122,122,0.1);
      border: 1px solid rgba(232,122,122,0.3);
      color: #e87a7a;
    }
    .result-warn {
      background: rgba(232,200,122,0.1);
      border: 1px solid rgba(232,200,122,0.3);
      color: #e8c87a;
    }
    .result-info {
      background: rgba(122,184,232,0.1);
      border: 1px solid rgba(122,184,232,0.3);
      color: #7ab8e8;
    }
    .live-table { margin-bottom: 24px; }
    .section-title {
      font-family: monospace;
      font-size: 11px;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: #6b7280;
      margin-bottom: 12px;
    }
    .qty-cell { font-family: monospace; font-weight: 700; font-size: 16px; }
    .qty-zero { color: #e87a7a; }
    .qty-ok   { color: #8be8a4; }
    .reset-bar {
      background: #13161d;
      border: 1px solid #252a36;
      border-radius: 12px;
      padding: 20px 24px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 24px;
    }
    .step-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 24px; height: 24px;
      background: #e8c87a;
      color: #0d0f14;
      border-radius: 50%;
      font-size: 12px;
      font-weight: 700;
      margin-right: 8px;
      flex-shrink: 0;
    }
  </style>
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">

  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
    <h2 style="margin-bottom:0">⚡ Trigger Testing Panel</h2>
    <span style="font-size:12px;color:#6b7280;font-family:monospace">Task 5 — Live Demo</span>
  </div>
  <p style="color:#6b7280;font-size:13px;margin-bottom:24px">
    Click each button to fire the trigger directly from the UI. Results appear instantly below each card.
  </p>

  <!-- RESULT BOX -->
  <c:if test="${testResult != null}">
    <div class="result-box result-${testStatus}">
      <span style="font-size:20px">
        <c:choose>
          <c:when test="${testStatus == 'success'}">✅</c:when>
          <c:when test="${testStatus == 'fail'}">❌</c:when>
          <c:when test="${testStatus == 'warn'}">⚠️</c:when>
          <c:otherwise>🔄</c:otherwise>
        </c:choose>
      </span>
      <div>
        <div style="font-size:11px;font-family:monospace;opacity:0.7;margin-bottom:4px">
          TRIGGER TEST RESULT
        </div>
        ${testResult}
      </div>
    </div>
  </c:if>

  <!-- RESET BAR -->
  <div class="reset-bar">
    <div>
      <div style="font-weight:600;margin-bottom:2px">Reset Database</div>
      <div style="font-size:12px;color:#6b7280">
        Clears all borrows and fines, restores original book quantities before each demo
      </div>
    </div>
    <form method="post" action="triggerdemo">
      <input type="hidden" name="action" value="reset">
      <button type="submit" class="btn btn-ghost">🔄 Reset DB</button>
    </form>
  </div>

  <!-- TRIGGER CARDS -->
  <div class="demo-grid">

    <!-- Trigger 1 -->
    <div class="trigger-card red">
      <div class="timing">BEFORE INSERT on book_info</div>
      <h3>check_book_availability</h3>
      <p>
        Sets Book ID 7 (Linear Algebra) quantity to 0, then tries to issue it.
        The trigger should block the INSERT and throw an error.
      </p>
      <form method="post" action="triggerdemo">
        <input type="hidden" name="action" value="test_availability">
        <button type="submit" class="btn btn-danger" style="width:100%">
          ▶ Run Test — Issue Zero-Qty Book
        </button>
      </form>
    </div>

    <!-- Trigger 2 -->
    <div class="trigger-card red">
      <div class="timing">BEFORE INSERT on book_info</div>
      <h3>check_max_books</h3>
      <p>
        Issues 2 books to Ananya Singh (Plan: max 2 books), then tries to issue
        a 3rd. The trigger should block the 3rd INSERT.
      </p>
      <form method="post" action="triggerdemo">
        <input type="hidden" name="action" value="test_maxbooks">
        <button type="submit" class="btn btn-danger" style="width:100%">
          ▶ Run Test — Exceed Book Limit
        </button>
      </form>
    </div>

    <!-- Trigger 3 -->
    <div class="trigger-card green">
      <div class="timing">AFTER INSERT on book_info</div>
      <h3>reduce_quantity_on_issue</h3>
      <p>
        Issues Sapiens (Book ID 5) to Sneha Gupta. Checks quantity before and
        after — trigger should auto-decrement it by 1.
      </p>
      <form method="post" action="triggerdemo">
        <input type="hidden" name="action" value="test_reduce">
        <button type="submit" class="btn btn-primary" style="width:100%">
          ▶ Run Test — Auto Reduce Quantity
        </button>
      </form>
    </div>

    <!-- Trigger 4 -->
    <div class="trigger-card green">
      <div class="timing">AFTER UPDATE on book_info</div>
      <h3>increase_quantity_on_return</h3>
      <p>
        Returns the most recently issued book. Checks quantity before and after
        — trigger should auto-increment it by 1.
      </p>
      <form method="post" action="triggerdemo">
        <input type="hidden" name="action" value="test_increase">
        <button type="submit" class="btn btn-primary" style="width:100%">
          ▶ Run Test — Auto Increase Quantity
        </button>
      </form>
    </div>

    <!-- Trigger 5 -->
    <div class="trigger-card blue" style="grid-column: span 2;">
      <div class="timing">AFTER UPDATE on book_info</div>
      <h3>generate_fine</h3>
      <p>
        Issues a book with Due Date set to <strong>2024-01-15</strong> (past), then returns it.
        The trigger should automatically insert a ₹50 fine record into the fine table
        — without any INSERT statement in the Java code.
      </p>
      <form method="post" action="triggerdemo">
        <input type="hidden" name="action" value="test_fine">
        <button type="submit" class="btn" style="width:100%;background:#7ab8e8;color:#0d0f14;font-weight:700">
          ▶ Run Test — Auto Generate Fine for Overdue Return
        </button>
      </form>
    </div>

  </div>

  <!-- LIVE BOOK QUANTITIES -->
  <div class="live-table">
    <div class="section-title">📚 Live Book Quantities (updates after each test)</div>
    <div class="card" style="padding:0">
      <table>
        <thead>
          <tr><th>Book ID</th><th>Title</th><th>Current Quantity</th></tr>
        </thead>
        <tbody>
          <c:forEach var="b" items="${books}">
            <tr>
              <td style="font-family:monospace">#${b.Book_Id}</td>
              <td>${b.Title}</td>
              <td>
                <span class="qty-cell ${b.Quantity == 0 ? 'qty-zero' : 'qty-ok'}">
                  ${b.Quantity}
                  <c:if test="${b.Quantity == 0}"> ← ZERO</c:if>
                </span>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </div>

  <!-- LIVE MEMBER BOOK COUNTS -->
  <div class="live-table">
    <div class="section-title">👤 Live Member Book Counts (vs their plan limit)</div>
    <div class="card" style="padding:0">
      <table>
        <thead>
          <tr><th>Member</th><th>Currently Issued</th><th>Max Allowed</th><th>Status</th></tr>
        </thead>
        <tbody>
          <c:forEach var="m" items="${members}">
            <tr>
              <td><strong>${m.Name}</strong></td>
              <td style="font-family:monospace;font-size:16px;font-weight:700">${m.Current_Count}</td>
              <td style="font-family:monospace">${m.Max_Book_Allowed}</td>
              <td>
                <c:choose>
                  <c:when test="${m.Current_Count >= m.Max_Book_Allowed}">
                    <span class="badge badge-red">AT LIMIT</span>
                  </c:when>
                  <c:when test="${m.Current_Count > 0}">
                    <span class="badge badge-yellow">Active</span>
                  </c:when>
                  <c:otherwise>
                    <span class="badge badge-green">Available</span>
                  </c:otherwise>
                </c:choose>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </div>

  <!-- LIVE FINES -->
  <div class="live-table">
    <div class="section-title">💰 Live Fine Records (auto-generated by trigger)</div>
    <div class="card" style="padding:0">
      <table>
        <thead>
          <tr><th>Fine ID</th><th>Member</th><th>Amount</th><th>Status</th></tr>
        </thead>
        <tbody>
          <c:choose>
            <c:when test="${empty fines}">
              <tr>
                <td colspan="4" style="text-align:center;padding:24px;color:#6b7280">
                  No fines yet — run Test 5 to auto-generate one
                </td>
              </tr>
            </c:when>
            <c:otherwise>
              <c:forEach var="f" items="${fines}">
                <tr>
                  <td style="font-family:monospace">#${f.Fine_Id}</td>
                  <td>${f.member_name}</td>
                  <td style="color:#e87a7a;font-weight:700">₹${f.Amount}</td>
                  <td>
                    <c:choose>
                      <c:when test="${f.Paid_Status == 'Paid'}">
                        <span class="badge badge-green">Paid</span>
                      </c:when>
                      <c:otherwise>
                        <span class="badge badge-red">Unpaid</span>
                      </c:otherwise>
                    </c:choose>
                  </td>
                </tr>
              </c:forEach>
            </c:otherwise>
          </c:choose>
        </tbody>
      </table>
    </div>
  </div>

</div>
</body>
</html>
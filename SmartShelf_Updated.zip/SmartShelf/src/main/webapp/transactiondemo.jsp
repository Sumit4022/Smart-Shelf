<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html>
<head>
  <title>Transaction Demo — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .tx-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 10px;
      margin-bottom: 24px;
    }
    .tx-card {
      background: #13161d;
      border: 1px solid #252a36;
      border-radius: 10px;
      padding: 16px;
      cursor: pointer;
      transition: border-color 0.15s, background 0.15s;
      text-decoration: none;
      display: block;
    }
    .tx-card:hover { border-color: #3a4055; background: #181c26; }
    .tx-card.active { border-color: #e8c87a; background: rgba(232,200,122,0.06); }
    .tx-card.active .tx-num { color: #e8c87a; }
    .tx-num {
      font-size: 10px;
      font-family: monospace;
      letter-spacing: 1.5px;
      text-transform: uppercase;
      color: #6b7280;
      margin-bottom: 4px;
    }
    .tx-title { font-size: 12px; font-weight: 600; color: #e8e4d8; margin-bottom: 6px; line-height: 1.4; }
    .tx-type {
      display: inline-block;
      font-size: 9px;
      font-weight: 700;
      padding: 2px 7px;
      border-radius: 100px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .type-commit  { background: rgba(139,232,164,0.12); color: #8be8a4; border: 1px solid rgba(139,232,164,0.2); }
    .type-conflict{ background: rgba(232,200,122,0.12); color: #e8c87a; border: 1px solid rgba(232,200,122,0.2); }
    .type-rollback{ background: rgba(232,122,122,0.12); color: #e87a7a; border: 1px solid rgba(232,122,122,0.2); }

    .main-grid { display: grid; grid-template-columns: 340px 1fr; gap: 20px; margin-bottom: 24px; }

    .sql-panel {
      background: #13161d;
      border: 1px solid #252a36;
      border-radius: 12px;
      overflow: hidden;
    }
    .sql-panel-head {
      padding: 12px 16px;
      border-bottom: 1px solid #252a36;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .sql-panel-head span { font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: #6b7280; }
    .sql-body { padding: 16px; font-family: monospace; font-size: 12px; line-height: 1.8; color: #c9d1d9; white-space: pre; }
    .kw  { color: #7ab8e8; font-weight: 600; }
    .cm  { color: #484f58; font-style: italic; }
    .str { color: #8be8a4; }
    .fn  { color: #e8c87a; }

    .steps-panel {
      background: #13161d;
      border: 1px solid #252a36;
      border-radius: 12px;
      overflow: hidden;
    }
    .steps-head {
      padding: 12px 16px;
      border-bottom: 1px solid #252a36;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .steps-head span { font-size: 10px; letter-spacing: 2px; text-transform: uppercase; color: #6b7280; }
    .steps-body { padding: 16px; }
    .step-row { display: flex; gap: 10px; align-items: flex-start; margin-bottom: 10px; }
    .step-row:last-child { margin-bottom: 0; }
    .step-dot {
      width: 22px; height: 22px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center;
      font-size: 10px; font-weight: 700; flex-shrink: 0; margin-top: 1px;
    }
    .dot-ok    { background: rgba(139,232,164,0.15); color: #8be8a4; border: 1px solid rgba(139,232,164,0.3); }
    .dot-err   { background: rgba(232,122,122,0.15); color: #e87a7a; border: 1px solid rgba(232,122,122,0.3); }
    .dot-warn  { background: rgba(232,200,122,0.15); color: #e8c87a; border: 1px solid rgba(232,200,122,0.3); }
    .step-text { font-size: 12px; color: #9ca3af; line-height: 1.5; padding-top: 3px; }
    .step-text strong { color: #e8e4d8; font-weight: 600; }

    .run-btn-row { padding: 12px 16px; border-top: 1px solid #252a36; display: flex; gap: 8px; align-items: center; }

    .result-bar {
      padding: 14px 20px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 500;
      margin-bottom: 20px;
      display: flex;
      align-items: flex-start;
      gap: 12px;
      line-height: 1.6;
    }
    .result-success { background: rgba(139,232,164,0.08); border: 1px solid rgba(139,232,164,0.25); color: #8be8a4; }
    .result-fail    { background: rgba(232,122,122,0.08); border: 1px solid rgba(232,122,122,0.25); color: #e87a7a; }
    .result-conflict{ background: rgba(232,200,122,0.08); border: 1px solid rgba(232,200,122,0.25); color: #e8c87a; }
    .result-rollback{ background: rgba(232,122,122,0.08); border: 1px solid rgba(232,122,122,0.25); color: #e87a7a; }
    .result-info    { background: rgba(122,184,232,0.08); border: 1px solid rgba(122,184,232,0.25); color: #7ab8e8; }
    .result-warn    { background: rgba(232,200,122,0.08); border: 1px solid rgba(232,200,122,0.25); color: #e8c87a; }

    .log-box {
      background: #0d0f14;
      border: 1px solid #252a36;
      border-radius: 10px;
      padding: 14px 16px;
      margin-bottom: 20px;
      font-family: monospace;
      font-size: 11.5px;
      line-height: 1.9;
      color: #6b7280;
    }
    .log-box .log-ok   { color: #8be8a4; }
    .log-box .log-err  { color: #e87a7a; }
    .log-box .log-tx   { color: #e8c87a; }
    .log-box .log-info { color: #7ab8e8; }

    .live-section-title {
      font-size: 10px; letter-spacing: 2px; text-transform: uppercase;
      color: #6b7280; margin-bottom: 10px; margin-top: 24px;
    }
    .qty-cell { font-family: monospace; font-weight: 700; font-size: 15px; }
    .qty-zero { color: #e87a7a; }
    .qty-ok   { color: #8be8a4; }
    .qty-low  { color: #e8c87a; }

    .reset-bar {
      background: #13161d; border: 1px solid #252a36; border-radius: 10px;
      padding: 14px 20px; display: flex; align-items: center;
      justify-content: space-between; margin-bottom: 20px;
    }

    .tx-desc { font-size: 12px; color: #6b7280; margin-top: 3px; }

    @media (max-width: 900px) {
      .tx-grid { grid-template-columns: repeat(2, 1fr); }
      .main-grid { grid-template-columns: 1fr; }
    }
  </style>
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">

  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px">
    <h2 style="margin-bottom:0">🔄 Transaction Demo Panel</h2>
    <span style="font-size:11px;color:#6b7280;font-family:monospace">Task 6 — Live Execution</span>
  </div>
  <p style="color:#6b7280;font-size:13px;margin-bottom:22px">
    Select a transaction below to view its SQL and description, then click Run to execute it live against the database.
    Commit, Conflict, and Rollback behaviours are all demonstrated with real data.
  </p>

  <%-- RESET BAR --%>
  <div class="reset-bar">
    <div>
      <div style="font-weight:600;font-size:13px;margin-bottom:2px">Reset Database</div>
      <div style="font-size:11px;color:#6b7280">Clears all borrows, fines, and test books. Restores original book quantities.</div>
    </div>
    <form method="post" action="transactiondemo">
      <input type="hidden" name="action" value="reset">
      <button type="submit" class="btn btn-ghost">🔄 Reset DB</button>
    </form>
  </div>

  <%-- RESULT BAR --%>
  <c:if test="${txResult != null}">
    <div class="result-bar result-${txStatus}">
      <span style="font-size:18px">
        <c:choose>
          <c:when test="${txStatus == 'success'}">✅</c:when>
          <c:when test="${txStatus == 'conflict'}">⚠️</c:when>
          <c:when test="${txStatus == 'rollback'}">↩️</c:when>
          <c:when test="${txStatus == 'fail'}">❌</c:when>
          <c:when test="${txStatus == 'warn'}">⚠️</c:when>
          <c:otherwise>ℹ️</c:otherwise>
        </c:choose>
      </span>
      <div>
        <div style="font-size:10px;font-family:monospace;opacity:0.6;margin-bottom:3px">TRANSACTION RESULT</div>
        ${txResult}
      </div>
    </div>

    <%-- Execution Log --%>
    <c:if test="${not empty txLog}">
      <div class="log-box">
        <div style="font-size:10px;letter-spacing:2px;color:#3a4055;margin-bottom:8px">EXECUTION LOG</div>
        <c:forEach var="line" items="${txLog}">
          <c:choose>
            <c:when test="${fn:containsIgnoreCase(line, 'COMMIT')}">
              <div class="log-tx">▶ ${line}</div>
            </c:when>
            <c:when test="${fn:containsIgnoreCase(line, 'ROLLBACK') or fn:containsIgnoreCase(line, 'BLOCKED') or fn:containsIgnoreCase(line, 'failed') or fn:containsIgnoreCase(line, 'EXCEPTION')}">
              <div class="log-err">✕ ${line}</div>
            </c:when>
            <c:when test="${fn:containsIgnoreCase(line, 'VERIFY') or fn:containsIgnoreCase(line, 'count') or fn:containsIgnoreCase(line, 'ROW_COUNT')}">
              <div class="log-info">→ ${line}</div>
            </c:when>
            <c:when test="${fn:containsIgnoreCase(line, 'START') or fn:containsIgnoreCase(line, 'SESSION')}">
              <div class="log-tx">· ${line}</div>
            </c:when>
            <c:otherwise>
              <div>${line}</div>
            </c:otherwise>
          </c:choose>
        </c:forEach>
      </div>
    </c:if>
  </c:if>

  <%-- TRANSACTION SELECTOR GRID --%>
  <div class="tx-grid">

    <a href="#" onclick="showTx('t1')" class="tx-card ${lastAction == 't1_issue' ? 'active' : ''}">
      <div class="tx-num">T1</div>
      <div class="tx-title">Issue a Book</div>
      <span class="tx-type type-commit">Commit</span>
    </a>

    <a href="#" onclick="showTx('t2')" class="tx-card ${lastAction == 't2_return' ? 'active' : ''}">
      <div class="tx-num">T2</div>
      <div class="tx-title">Return + Auto Fine</div>
      <span class="tx-type type-commit">Commit + Trigger</span>
    </a>

    <a href="#" onclick="showTx('t3')" class="tx-card ${lastAction == 't3_payFine' ? 'active' : ''}">
      <div class="tx-num">T3</div>
      <div class="tx-title">Pay a Fine</div>
      <span class="tx-type type-commit">Commit</span>
    </a>

    <a href="#" onclick="showTx('t4')" class="tx-card ${lastAction == 't4_addBook' ? 'active' : ''}">
      <div class="tx-num">T4</div>
      <div class="tx-title">Add Book + Reservation</div>
      <span class="tx-type type-commit">Multi-step Commit</span>
    </a>

    <a href="#" onclick="showTx('t5')" class="tx-card ${lastAction == 't5_conflict' ? 'active' : ''}">
      <div class="tx-num">T5</div>
      <div class="tx-title">Last-Copy Race</div>
      <span class="tx-type type-conflict">Conflict</span>
    </a>

    <a href="#" onclick="showTx('t6')" class="tx-card ${lastAction == 't6_limit' ? 'active' : ''}">
      <div class="tx-num">T6</div>
      <div class="tx-title">Book Limit Exceeded</div>
      <span class="tx-type type-conflict">Conflict</span>
    </a>

    <a href="#" onclick="showTx('t7')" class="tx-card ${lastAction == 't7_dirtyWrite' ? 'active' : ''}">
      <div class="tx-num">T7</div>
      <div class="tx-title">Concurrent Fine Payment</div>
      <span class="tx-type type-conflict">Lost Update Safe</span>
    </a>

    <a href="#" onclick="showTx('t8')" class="tx-card ${lastAction == 't8_rollback' ? 'active' : ''}">
      <div class="tx-num">T8</div>
      <div class="tx-title">Duplicate Email</div>
      <span class="tx-type type-rollback">Rollback</span>
    </a>

  </div>

  <%-- DETAIL PANEL --%>
  <div id="txDetail" class="main-grid" style="display:none">

    <%-- SQL Panel --%>
    <div class="sql-panel">
      <div class="sql-panel-head">
        <span>SQL</span>
        <span id="txBadge" class="tx-type"></span>
      </div>
      <div class="sql-body" id="txSql"></div>
    </div>

    <%-- Steps + Run --%>
    <div class="steps-panel">
      <div class="steps-head">
        <span id="txHeading">Steps</span>
        <span id="txTypeLabel" style="font-size:11px;color:#6b7280"></span>
      </div>
      <div class="steps-body" id="txSteps"></div>
      <div class="run-btn-row">
        <form method="post" action="transactiondemo" style="flex:1">
          <input type="hidden" name="action" id="txAction" value="">
          <button type="submit" id="txRunBtn" class="btn btn-primary" style="width:100%">
            ▶ Run Transaction
          </button>
        </form>
      </div>
    </div>

  </div>

  <%-- LIVE DATA TABLES --%>
  <div class="live-section-title">📚 Live Book Quantities</div>
  <div class="card" style="padding:0;margin-bottom:20px">
    <table>
      <thead>
        <tr><th>ID</th><th>Title</th><th>Quantity</th></tr>
      </thead>
      <tbody>
        <c:forEach var="b" items="${books}">
          <tr>
            <td style="font-family:monospace">#${b.Book_Id}</td>
            <td>${b.Title}</td>
            <td>
              <span class="qty-cell
                ${b.Quantity == 0 ? 'qty-zero' : (b.Quantity <= 1 ? 'qty-low' : 'qty-ok')}">
                ${b.Quantity}
                <c:if test="${b.Quantity == 0}"> ← ZERO</c:if>
              </span>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>

  <div class="live-section-title">👤 Live Member Borrow Counts</div>
  <div class="card" style="padding:0;margin-bottom:20px">
    <table>
      <thead>
        <tr><th>Member</th><th>Currently Issued</th><th>Max Allowed</th><th>Status</th></tr>
      </thead>
      <tbody>
        <c:forEach var="m" items="${members}">
          <tr>
            <td><strong>${m.Name}</strong></td>
            <td style="font-family:monospace;font-size:16px;font-weight:700">${m.Current_Count}</td>
            <td style="font-family:monospace">${m.Max_Book_Allowed}</td>
            <td>
              <c:choose>
                <c:when test="${m.Current_Count >= m.Max_Book_Allowed}">
                  <span class="badge badge-red">AT LIMIT</span>
                </c:when>
                <c:when test="${m.Current_Count > 0}">
                  <span class="badge badge-yellow">Active</span>
                </c:when>
                <c:otherwise>
                  <span class="badge badge-green">Available</span>
                </c:otherwise>
              </c:choose>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>

  <div class="live-section-title">💰 Live Fine Records</div>
  <div class="card" style="padding:0;margin-bottom:20px">
    <table>
      <thead>
        <tr><th>Fine ID</th><th>Member</th><th>Amount</th><th>Status</th></tr>
      </thead>
      <tbody>
        <c:choose>
          <c:when test="${empty fines}">
            <tr>
              <td colspan="4" style="text-align:center;padding:24px;color:#6b7280">
                No fines yet — run T2 to auto-generate one via trigger
              </td>
            </tr>
          </c:when>
          <c:otherwise>
            <c:forEach var="f" items="${fines}">
              <tr>
                <td style="font-family:monospace">#${f.Fine_Id}</td>
                <td>${f.member_name}</td>
                <td style="color:#e87a7a;font-weight:700">₹${f.Amount}</td>
                <td>
                  <c:choose>
                    <c:when test="${f.Paid_Status == 'Paid'}">
                      <span class="badge badge-green">Paid</span>
                    </c:when>
                    <c:otherwise>
                      <span class="badge badge-red">Unpaid</span>
                    </c:otherwise>
                  </c:choose>
                </td>
              </tr>
            </c:forEach>
          </c:otherwise>
        </c:choose>
      </tbody>
    </table>
  </div>

</div>

<script>
const TX = {
  t1: {
    action: "t1_issue",
    heading: "T1 — Issue a Book",
    type: "Commit",
    typeClass: "type-commit",
    typeLabel: "Normal Successful Transaction",
    sql: `<span class='kw'>START TRANSACTION</span>;

<span class='cm'>-- Insert borrow record</span>
<span class='kw'>INSERT INTO</span> book_info (
  Borrow_Date, Borrow_Time, Due_Date,
  Status, Librarian_Id, Member_Id, Book_Id
)
<span class='kw'>VALUES</span> (
  <span class='fn'>CURDATE</span>(), <span class='fn'>CURTIME</span>(),
  <span class='fn'>DATE_ADD</span>(CURDATE(), INTERVAL 14 DAY),
  <span class='str'>'Issued'</span>, 1, 6, 3
);

<span class='cm'>-- Trigger reduce_quantity_on_issue</span>
<span class='cm'>-- fires automatically here</span>

<span class='kw'>COMMIT</span>;`,
    steps: [
      { ok: true,  text: "<strong>INSERT</strong> borrow record — Member 6 borrows Book 3" },
      { ok: true,  text: "<strong>Trigger fires</strong> — reduce_quantity_on_issue decrements qty by 1" },
      { ok: true,  text: "<strong>COMMIT</strong> — insert + quantity change persisted atomically" },
    ]
  },
  t2: {
    action: "t2_return",
    heading: "T2 — Return + Auto Fine",
    type: "Trigger",
    typeClass: "type-commit",
    typeLabel: "Return with Auto Fine Generation",
    sql: `<span class='kw'>START TRANSACTION</span>;

<span class='cm'>-- Simulate overdue</span>
<span class='kw'>UPDATE</span> book_info
<span class='kw'>SET</span> Due_Date = <span class='str'>'2024-01-01'</span>
<span class='kw'>WHERE</span> Borrow_Id = [last];

<span class='cm'>-- Return triggers generate_fine</span>
<span class='kw'>UPDATE</span> book_info
<span class='kw'>SET</span> Status = <span class='str'>'Returned'</span>
<span class='kw'>WHERE</span> Borrow_Id = [last];

<span class='kw'>COMMIT</span>;`,
    steps: [
      { ok: true,  text: "<strong>UPDATE</strong> Due_Date → past date (simulate overdue)" },
      { ok: true,  text: "<strong>UPDATE</strong> Status → 'Returned'" },
      { ok: true,  text: "<strong>Trigger fires</strong> — generate_fine auto-inserts fine record" },
      { ok: true,  text: "<strong>COMMIT</strong> — return + fine persisted together" },
    ]
  },
  t3: {
    action: "t3_payFine",
    heading: "T3 — Pay a Fine",
    type: "Commit",
    typeClass: "type-commit",
    typeLabel: "Atomic Fine Payment",
    sql: `<span class='kw'>START TRANSACTION</span>;

<span class='cm'>-- Conditional update prevents</span>
<span class='cm'>-- double-payment</span>
<span class='kw'>UPDATE</span> fine
<span class='kw'>SET</span> Paid_Status = <span class='str'>'Paid'</span>
<span class='kw'>WHERE</span> Fine_Id = [unpaid]
  <span class='kw'>AND</span> Paid_Status = <span class='str'>'Unpaid'</span>;

<span class='kw'>SELECT</span> <span class='fn'>ROW_COUNT</span>()
  AS rows_updated;
<span class='cm'>-- Should be 1</span>

<span class='kw'>COMMIT</span>;`,
    steps: [
      { ok: true,  text: "<strong>Find</strong> first unpaid fine" },
      { ok: true,  text: "<strong>UPDATE</strong> Paid_Status = 'Paid' WHERE Paid_Status = 'Unpaid'" },
      { ok: true,  text: "<strong>ROW_COUNT()</strong> = 1 confirms update succeeded" },
      { ok: true,  text: "<strong>COMMIT</strong> — payment persisted atomically" },
    ]
  },
  t4: {
    action: "t4_addBook",
    heading: "T4 — Add Book + Reservation",
    type: "Multi-step",
    typeClass: "type-commit",
    typeLabel: "Multi-step Atomic Transaction",
    sql: `<span class='kw'>START TRANSACTION</span>;

<span class='kw'>INSERT INTO</span> book
  (Title, Author, ISBN, Quantity ...)
<span class='kw'>VALUES</span> (<span class='str'>'Design Patterns'</span>, ...);

<span class='kw'>SELECT</span> @id :=
  <span class='fn'>LAST_INSERT_ID</span>();

<span class='kw'>INSERT INTO</span> reservation
  (Status, Book_Id, Member_Id)
<span class='kw'>VALUES</span> (<span class='str'>'Pending'</span>, @id, 2);

<span class='kw'>UPDATE</span> reservation
<span class='kw'>SET</span> Status = <span class='str'>'Approved'</span>
<span class='kw'>WHERE</span> Book_Id = @id;

<span class='kw'>COMMIT</span>;`,
    steps: [
      { ok: true,  text: "<strong>INSERT</strong> new book 'Design Patterns' (Qty: 3)" },
      { ok: true,  text: "<strong>LAST_INSERT_ID()</strong> captured as @new_book_id" },
      { ok: true,  text: "<strong>INSERT</strong> reservation for Member 2 (Status: Pending)" },
      { ok: true,  text: "<strong>UPDATE</strong> reservation → Status: 'Approved'" },
      { ok: true,  text: "<strong>COMMIT</strong> — book + reservation + approval all atomic" },
    ]
  },
  t5: {
    action: "t5_conflict",
    heading: "T5 — Last-Copy Race Condition",
    type: "Conflict",
    typeClass: "type-conflict",
    typeLabel: "Conflicting Concurrent Transactions",
    sql: `<span class='cm'>-- Force last copy</span>
<span class='kw'>UPDATE</span> book
<span class='kw'>SET</span> Quantity = 1
<span class='kw'>WHERE</span> Book_Id = 6;

<span class='cm'>-- Session A (succeeds)</span>
<span class='kw'>START TRANSACTION</span>;
<span class='kw'>INSERT INTO</span> book_info ...
  Book_Id = 6;
<span class='kw'>COMMIT</span>; <span class='cm'>-- Qty now 0</span>

<span class='cm'>-- Session B (conflicts)</span>
<span class='kw'>START TRANSACTION</span>;
<span class='cm'>-- Trigger raises SIGNAL:</span>
<span class='cm'>-- 'Book not available!'</span>
<span class='kw'>ROLLBACK</span>;`,
    steps: [
      { ok: true,  text: "<strong>Setup:</strong> Book 6 quantity forced to 1 (last copy)" },
      { ok: true,  text: "<strong>Session A:</strong> INSERT borrow + trigger fires → Qty → 0" },
      { ok: true,  text: "<strong>Session A:</strong> COMMIT — last copy issued successfully" },
      { ok: false, text: "<strong>Session B:</strong> INSERT blocked — trigger raises SIGNAL '45000'" },
      { ok: false, text: "<strong>Session B:</strong> ROLLBACK — no record inserted, qty stays 0" },
    ]
  },
  t6: {
    action: "t6_limit",
    heading: "T6 — Book Limit Exceeded",
    type: "Conflict",
    typeClass: "type-conflict",
    typeLabel: "Membership Limit Conflict",
    sql: `<span class='cm'>-- Member 2: Max_Book_Allowed = 2</span>

<span class='cm'>-- Borrow 1 (ok)</span>
<span class='kw'>START TRANSACTION</span>;
<span class='kw'>INSERT INTO</span> book_info ...
  Member_Id=2, Book_Id=1;
<span class='kw'>COMMIT</span>;

<span class='cm'>-- Borrow 2 (ok)</span>
<span class='kw'>START TRANSACTION</span>;
<span class='kw'>INSERT INTO</span> book_info ...
  Member_Id=2, Book_Id=2;
<span class='kw'>COMMIT</span>; <span class='cm'>-- Now at limit</span>

<span class='cm'>-- Borrow 3 (blocked!)</span>
<span class='kw'>START TRANSACTION</span>;
<span class='cm'>-- Trigger: 'Book limit exceeded!'</span>
<span class='kw'>ROLLBACK</span>;`,
    steps: [
      { ok: true,  text: "<strong>Reset:</strong> Clear existing borrows for Member 2" },
      { ok: true,  text: "<strong>Borrow 1:</strong> Book 1 → Member 2 — COMMIT (1/2)" },
      { ok: true,  text: "<strong>Borrow 2:</strong> Book 2 → Member 2 — COMMIT (2/2 at limit)" },
      { ok: false, text: "<strong>Borrow 3:</strong> trigger check_max_books raises 'Book limit exceeded!'" },
      { ok: false, text: "<strong>ROLLBACK</strong> — 3rd borrow aborted, active count stays 2" },
    ]
  },
  t7: {
    action: "t7_dirtyWrite",
    heading: "T7 — Concurrent Fine Payment",
    type: "Safe",
    typeClass: "type-conflict",
    typeLabel: "Lost Update Handled Safely",
    sql: `<span class='cm'>-- Session A pays fine</span>
<span class='kw'>START TRANSACTION</span>;
<span class='kw'>UPDATE</span> fine
<span class='kw'>SET</span> Paid_Status = <span class='str'>'Paid'</span>
<span class='kw'>WHERE</span> Fine_Id = [id]
  <span class='kw'>AND</span> Paid_Status = <span class='str'>'Unpaid'</span>;
<span class='cm'>-- ROW_COUNT() → 1</span>
<span class='kw'>COMMIT</span>;

<span class='cm'>-- Session B (late)</span>
<span class='kw'>START TRANSACTION</span>;
<span class='kw'>UPDATE</span> fine
<span class='kw'>SET</span> Paid_Status = <span class='str'>'Paid'</span>
<span class='kw'>WHERE</span> Fine_Id = [id]
  <span class='kw'>AND</span> Paid_Status = <span class='str'>'Unpaid'</span>;
<span class='cm'>-- ROW_COUNT() → 0 (no-op)</span>
<span class='kw'>COMMIT</span>;`,
    steps: [
      { ok: true,  text: "<strong>Setup:</strong> Fine reset to 'Unpaid'" },
      { ok: true,  text: "<strong>Session A:</strong> UPDATE WHERE Paid_Status='Unpaid' → ROW_COUNT=1" },
      { ok: true,  text: "<strong>Session A:</strong> COMMIT — fine marked Paid" },
      { ok: true,  text: "<strong>Session B:</strong> same UPDATE — ROW_COUNT=0 (already paid, no-op)" },
      { ok: true,  text: "<strong>Session B:</strong> COMMIT — no duplication, no corruption" },
    ]
  },
  t8: {
    action: "t8_rollback",
    heading: "T8 — Duplicate Email Rollback",
    type: "Rollback",
    typeClass: "type-rollback",
    typeLabel: "UNIQUE Constraint Violation",
    sql: `<span class='kw'>START TRANSACTION</span>;

<span class='kw'>INSERT INTO</span> member (
  Name, Username, Password,
  Email_Id, Phone_Number,
  Membership_Type_Id,
  Membership_Start, Membership_Expiry
)
<span class='kw'>VALUES</span> (
  <span class='str'>'Rohit Duplicate'</span>,
  <span class='str'>'rohit_dup'</span>, <span class='str'>'pass123'</span>,
  <span class='str'>'rohit@mail.com'</span>, <span class='cm'>← UNIQUE!</span>
  9999999999, 1,
  CURDATE(), ...
);
<span class='cm'>-- ERROR: Duplicate entry</span>
<span class='cm'>-- for key 'Email_Id'</span>

<span class='kw'>ROLLBACK</span>;`,
    steps: [
      { ok: false, text: "<strong>INSERT</strong> member with email 'rohit@mail.com'" },
      { ok: false, text: "<strong>UNIQUE constraint violated</strong> — email already exists" },
      { ok: false, text: "<strong>ROLLBACK</strong> — entire transaction undone, no partial data" },
      { ok: true,  text: "<strong>VERIFY</strong> — original member record unchanged" },
    ]
  }
};

function showTx(key) {
  const t = TX[key];
  if (!t) return;

  document.querySelectorAll('.tx-card').forEach(c => c.classList.remove('active'));
  event.currentTarget.classList.add('active');

  document.getElementById('txSql').innerHTML = t.sql;
  document.getElementById('txAction').value = t.action;
  document.getElementById('txHeading').textContent = t.heading;
  document.getElementById('txTypeLabel').textContent = t.typeLabel;

  const badge = document.getElementById('txBadge');
  badge.textContent = t.type;
  badge.className = 'tx-type ' + t.typeClass;

  const runBtn = document.getElementById('txRunBtn');
  if (t.typeClass === 'type-rollback') {
    runBtn.style.background = 'rgba(232,122,122,0.15)';
    runBtn.style.color = '#e87a7a';
    runBtn.style.border = '1px solid rgba(232,122,122,0.2)';
  } else if (t.typeClass === 'type-conflict') {
    runBtn.style.background = 'rgba(232,200,122,0.15)';
    runBtn.style.color = '#e8c87a';
    runBtn.style.border = '1px solid rgba(232,200,122,0.2)';
  } else {
    runBtn.style.background = '#e8c87a';
    runBtn.style.color = '#0d0f14';
    runBtn.style.border = 'none';
  }

  const stepsDiv = document.getElementById('txSteps');
  stepsDiv.innerHTML = t.steps.map(s => `
    <div class="step-row">
      <div class="step-dot ${s.ok ? 'dot-ok' : 'dot-err'}">${s.ok ? '✓' : '✕'}</div>
      <div class="step-text">${s.text}</div>
    </div>
  `).join('');

  document.getElementById('txDetail').style.display = 'grid';
  document.getElementById('txDetail').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  return false;
}

// Auto-open last active transaction after form submit
<c:if test="${lastAction != null && lastAction != 'reset'}">
(function() {
  const actionMap = {
    't1_issue': 't1', 't2_return': 't2', 't3_payFine': 't3',
    't4_addBook': 't4', 't5_conflict': 't5', 't6_limit': 't6',
    't7_dirtyWrite': 't7', 't8_rollback': 't8'
  };
  const key = actionMap['${lastAction}'];
  if (key) {
    const t = TX[key];
    if (t) {
      document.getElementById('txSql').innerHTML = t.sql;
      document.getElementById('txAction').value = t.action;
      document.getElementById('txHeading').textContent = t.heading;
      document.getElementById('txTypeLabel').textContent = t.typeLabel;
      const badge = document.getElementById('txBadge');
      badge.textContent = t.type;
      badge.className = 'tx-type ' + t.typeClass;
      const stepsDiv = document.getElementById('txSteps');
      stepsDiv.innerHTML = t.steps.map(s =>
        '<div class="step-row"><div class="step-dot ' + (s.ok ? 'dot-ok' : 'dot-err') + '">' + (s.ok ? '✓' : '✕') + '</div><div class="step-text">' + s.text + '</div></div>'
      ).join('');
      document.getElementById('txDetail').style.display = 'grid';
    }
  }
})();
</c:if>
</script>

</body>
</html>

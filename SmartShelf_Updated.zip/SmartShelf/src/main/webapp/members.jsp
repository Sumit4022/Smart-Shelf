<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>Members — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">
  <h2>Library Members</h2>

  <c:if test="${param.error != null}">
    <div class="alert alert-error">❌ ${param.error}</div>
  </c:if>

  <div class="card">
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Name</th><th>Email</th>
          <th>Phone</th><th>Plan</th><th>Expiry</th>
        </tr>
      </thead>
      <tbody>
        <c:forEach var="m" items="${members}">
          <tr>
            <td>${m.Member_Id}</td>
            <td><strong>${m.Name}</strong></td>
            <td style="font-size:12px">${m.Email_Id}</td>
            <td style="font-family:monospace;font-size:12px">${m.Phone_Number}</td>
            <td><span class="badge">Plan ${m.Membership_Type_Id}</span></td>
            <td style="font-size:12px">${m.Membership_Expiry}</td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
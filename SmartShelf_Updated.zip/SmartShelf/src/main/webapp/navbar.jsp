<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<nav style="background:#13161d;padding:14px 32px;border-bottom:1px solid #252a36;
            display:flex;align-items:center;justify-content:space-between;">

  <div style="display:flex;align-items:center;gap:28px">
    <a href="dashboard" style="font-family:Georgia,serif;font-size:20px;
       color:#e8c87a;font-weight:700;text-decoration:none;">📚 SmartShelf</a>

    <a href="books" style="color:#9ca3af;text-decoration:none;font-size:14px;font-weight:500;">
      Books
    </a>

    <%-- Librarian and Admin only --%>
    <c:if test="${sessionScope.role == 'librarian' || sessionScope.role == 'admin'}">
      <a href="issue"   style="color:#9ca3af;text-decoration:none;font-size:14px;font-weight:500;">Issue</a>
      <a href="return"  style="color:#9ca3af;text-decoration:none;font-size:14px;font-weight:500;">Return</a>
      <a href="history" style="color:#9ca3af;text-decoration:none;font-size:14px;font-weight:500;">History</a>
      <a href="fines"   style="color:#9ca3af;text-decoration:none;font-size:14px;font-weight:500;">Fines</a>
    </c:if>

    <%-- Admin only --%>
    <c:if test="${sessionScope.role == 'admin'}">
      <a href="members" style="color:#9ca3af;text-decoration:none;font-size:14px;font-weight:500;">Members</a>
      <a href="querydemo" style="color:#8be8a4;text-decoration:none;font-size:14px;
         font-weight:600;border:1px solid #8be8a4;padding:4px 12px;border-radius:6px;">
        🗄️ Queries
      </a>
      <a href="triggerdemo" style="color:#e8c87a;text-decoration:none;font-size:14px;
         font-weight:600;border:1px solid #e8c87a;padding:4px 12px;border-radius:6px;">
        ⚡ Triggers
      </a>
      <a href="transactiondemo" style="color:#7ab8e8;text-decoration:none;font-size:14px;
         font-weight:600;border:1px solid #7ab8e8;padding:4px 12px;border-radius:6px;">
        🔄 Transactions
      </a>
    </c:if>

    <%-- Member only --%>
    <c:if test="${sessionScope.role == 'member'}">
      <a href="history" style="color:#9ca3af;text-decoration:none;font-size:14px;font-weight:500;">
        My History
      </a>
    </c:if>
  </div>

  <!-- Right side — user info + logout -->
  <div style="display:flex;align-items:center;gap:16px">
    <div style="text-align:right">
      <div style="font-weight:600;font-size:13px">${sessionScope.name}</div>
      <div style="font-size:11px;color:#6b7280;font-family:monospace;text-transform:uppercase">
        ${sessionScope.role}
      </div>
    </div>
    <a href="logout" style="background:rgba(232,122,122,0.15);color:#e87a7a;
       border:1px solid rgba(232,122,122,0.3);padding:7px 14px;border-radius:8px;
       text-decoration:none;font-size:13px;font-weight:600;">
      Logout
    </a>
  </div>

</nav>

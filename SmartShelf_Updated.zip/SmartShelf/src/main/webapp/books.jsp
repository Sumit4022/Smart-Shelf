<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>Books — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">
  <h2>Book Catalog</h2>

  <c:if test="${param.success != null}">
    <div class="alert alert-success">✅ ${param.success}</div>
  </c:if>
  <c:if test="${param.error != null}">
    <div class="alert alert-error">❌ ${param.error}</div>
  </c:if>

  <div class="card" style="margin-bottom:24px">
    <h3>Add New Book</h3>
    <form method="post" action="books" class="form-inline">
      <input type="hidden" name="action" value="add">
      <input type="text"   name="title"     placeholder="Title *"     required>
      <input type="text"   name="author"    placeholder="Author *"    required>
      <input type="text"   name="publisher" placeholder="Publisher">
      <input type="text"   name="isbn"      placeholder="ISBN *"      required>
      <select name="genre">
        <option>Technology</option>
        <option>Fiction</option>
        <option>Science</option>
        <option>History</option>
        <option>Philosophy</option>
        <option>Mathematics</option>
      </select>
      <input type="number" name="qty" value="1" min="0" style="width:70px">
      <button type="submit" class="btn btn-primary">Add Book</button>
    </form>
  </div>

  <div class="card">
    <table>
      <thead>
        <tr>
          <th>ID</th><th>Title</th><th>Author</th>
          <th>Genre</th><th>ISBN</th><th>Qty</th><th>Action</th>
        </tr>
      </thead>
      <tbody>
        <c:forEach var="b" items="${books}">
          <tr>
            <td>${b.Book_Id}</td>
            <td><strong>${b.Title}</strong></td>
            <td>${b.Author}</td>
            <td><span class="badge">${b.Genre_Type}</span></td>
            <td style="font-family:monospace;font-size:12px">${b.ISBN}</td>
            <td>
              <c:choose>
                <c:when test="${b.Quantity > 0}">
                  <span class="badge badge-green">${b.Quantity}</span>
                </c:when>
                <c:otherwise>
                  <span class="badge badge-red">0</span>
                </c:otherwise>
              </c:choose>
            </td>
            <td>
              <form method="post" action="books" style="display:inline">
                <input type="hidden" name="action"  value="delete">
                <input type="hidden" name="bookId"  value="${b.Book_Id}">
                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
              </form>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
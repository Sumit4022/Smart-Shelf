<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>Dashboard — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">

  <div style="margin-bottom:28px">
    <h2 style="margin-bottom:4px">
      Welcome back, ${sessionScope.name} 👋
    </h2>
    <span style="font-family:monospace;font-size:12px;color:#6b7280;
                 text-transform:uppercase;letter-spacing:1px">
      ${sessionScope.role} dashboard
    </span>
  </div>

  <!-- STATS -->
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:28px">
    <div class="card" style="border-top:3px solid #e8c87a;padding:20px">
      <div style="font-size:11px;font-family:monospace;letter-spacing:1.5px;
                  text-transform:uppercase;color:#6b7280;margin-bottom:8px">Total Books</div>
      <div style="font-family:Georgia,serif;font-size:32px;font-weight:700">${totalBooks}</div>
    </div>
    <div class="card" style="border-top:3px solid #7ab8e8;padding:20px">
      <div style="font-size:11px;font-family:monospace;letter-spacing:1.5px;
                  text-transform:uppercase;color:#6b7280;margin-bottom:8px">Total Members</div>
      <div style="font-family:Georgia,serif;font-size:32px;font-weight:700">${totalMembers}</div>
    </div>
    <div class="card" style="border-top:3px solid #8be8a4;padding:20px">
      <div style="font-size:11px;font-family:monospace;letter-spacing:1.5px;
                  text-transform:uppercase;color:#6b7280;margin-bottom:8px">Currently Issued</div>
      <div style="font-family:Georgia,serif;font-size:32px;font-weight:700">${totalIssued}</div>
    </div>
    <div class="card" style="border-top:3px solid #e87a7a;padding:20px">
      <div style="font-size:11px;font-family:monospace;letter-spacing:1.5px;
                  text-transform:uppercase;color:#6b7280;margin-bottom:8px">Unpaid Fines</div>
      <div style="font-family:Georgia,serif;font-size:32px;font-weight:700;color:#e87a7a">
        ₹${totalFines}
      </div>
    </div>
  </div>

  <!-- MEMBER VIEW -->
  <c:if test="${sessionScope.role == 'member'}">
    <div class="card" style="margin-bottom:20px">
      <h3 style="margin-bottom:16px">📖 My Borrowed Books</h3>
      <table>
        <thead>
          <tr><th>Title</th><th>Borrow Date</th><th>Due Date</th><th>Status</th></tr>
        </thead>
        <tbody>
          <c:choose>
            <c:when test="${empty myBooks}">
              <tr><td colspan="4" style="text-align:center;padding:24px;color:#6b7280">
                No books borrowed yet
              </td></tr>
            </c:when>
            <c:otherwise>
              <c:forEach var="b" items="${myBooks}">
                <tr>
                  <td><strong>${b.Title}</strong></td>
                  <td>${b.Borrow_Date}</td>
                  <td>${b.Due_Date}</td>
                  <td>
                    <c:choose>
                      <c:when test="${b.Status == 'Issued'}">
                        <span class="badge badge-yellow">Issued</span>
                      </c:when>
                      <c:otherwise>
                        <span class="badge badge-green">Returned</span>
                      </c:otherwise>
                    </c:choose>
                  </td>
                </tr>
              </c:forEach>
            </c:otherwise>
          </c:choose>
        </tbody>
      </table>
    </div>

    <div class="card">
      <h3 style="margin-bottom:16px">💰 My Fines</h3>
      <table>
        <thead>
          <tr><th>Book</th><th>Amount</th><th>Status</th></tr>
        </thead>
        <tbody>
          <c:choose>
            <c:when test="${empty myFines}">
              <tr><td colspan="3" style="text-align:center;padding:24px;color:#8be8a4">
                ✅ No fines!
              </td></tr>
            </c:when>
            <c:otherwise>
              <c:forEach var="f" items="${myFines}">
                <tr>
                  <td>${f.Title}</td>
                  <td style="color:#e87a7a;font-weight:700">₹${f.Amount}</td>
                  <td>
                    <c:choose>
                      <c:when test="${f.Paid_Status == 'Paid'}">
                        <span class="badge badge-green">Paid</span>
                      </c:when>
                      <c:otherwise>
                        <span class="badge badge-red">Unpaid</span>
                      </c:otherwise>
                    </c:choose>
                  </td>
                </tr>
              </c:forEach>
            </c:otherwise>
          </c:choose>
        </tbody>
      </table>
    </div>
  </c:if>

  <!-- ADMIN AND LIBRARIAN VIEW -->
  <c:if test="${sessionScope.role == 'admin' || sessionScope.role == 'librarian'}">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px">
      <div class="card">
        <h3 style="margin-bottom:16px">🕐 Recent Activity</h3>
        <table>
          <thead>
            <tr><th>Member</th><th>Book</th><th>Status</th></tr>
          </thead>
          <tbody>
            <c:forEach var="r" items="${recentActivity}">
              <tr>
                <td>${r.member_name}</td>
                <td>${r.book_title}</td>
                <td>
                  <c:choose>
                    <c:when test="${r.Status == 'Issued'}">
                      <span class="badge badge-yellow">Issued</span>
                    </c:when>
                    <c:otherwise>
                      <span class="badge badge-green">Returned</span>
                    </c:otherwise>
                  </c:choose>
                </td>
              </tr>
            </c:forEach>
          </tbody>
        </table>
      </div>

      <div class="card">
        <h3 style="margin-bottom:16px">💰 Unpaid Fines</h3>
        <table>
          <thead>
            <tr><th>Member</th><th>Amount</th></tr>
          </thead>
          <tbody>
            <c:choose>
              <c:when test="${empty unpaidFines}">
                <tr><td colspan="2" style="text-align:center;padding:24px;color:#8be8a4">
                  ✅ No unpaid fines
                </td></tr>
              </c:when>
              <c:otherwise>
                <c:forEach var="f" items="${unpaidFines}">
                  <tr>
                    <td>${f.member_name}</td>
                    <td style="color:#e87a7a;font-weight:700">₹${f.Amount}</td>
                  </tr>
                </c:forEach>
              </c:otherwise>
            </c:choose>
          </tbody>
        </table>
      </div>
    </div>
  </c:if>

</div>
</body>
</html>
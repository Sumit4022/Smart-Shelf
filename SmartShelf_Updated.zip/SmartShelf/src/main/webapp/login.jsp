<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>Login — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    body {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      background: #0d0f14;
    }
    .login-wrap {
      width: 100%;
      max-width: 420px;
      padding: 20px;
    }
    .login-logo {
      text-align: center;
      margin-bottom: 32px;
    }
    .login-logo h1 {
      font-family: Georgia, serif;
      font-size: 32px;
      color: #e8c87a;
      margin-bottom: 4px;
    }
    .login-logo p {
      color: #6b7280;
      font-size: 13px;
      font-family: monospace;
      letter-spacing: 2px;
      text-transform: uppercase;
    }
    .login-card {
      background: #13161d;
      border: 1px solid #252a36;
      border-radius: 16px;
      padding: 32px;
    }
    .role-tabs {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      margin-bottom: 24px;
    }
    .role-tab {
      padding: 10px;
      text-align: center;
      border-radius: 8px;
      border: 1px solid #252a36;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      color: #6b7280;
      background: #1a1e27;
      transition: all 0.15s;
    }
    .role-tab:hover { color: #e8e4d8; border-color: #e8c87a; }
    .role-tab.active {
      background: rgba(232,200,122,0.1);
      border-color: #e8c87a;
      color: #e8c87a;
    }
    .role-icon { font-size: 20px; display: block; margin-bottom: 4px; }
    .login-footer {
      text-align: center;
      margin-top: 20px;
      font-size: 12px;
      color: #6b7280;
    }
    .credentials-hint {
      background: #1a1e27;
      border: 1px solid #252a36;
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 11px;
      font-family: monospace;
      color: #6b7280;
      margin-bottom: 16px;
      line-height: 1.8;
    }
    .credentials-hint span { color: #e8c87a; }
  </style>
</head>
<body>
<div class="login-wrap">

  <div class="login-logo">
    <h1>📚 SmartShelf</h1>
    <p>Library Management System</p>
  </div>

  <div class="login-card">

    <c:if test="${error != null}">
      <div class="alert alert-error" style="margin-bottom:16px">❌ ${error}</div>
    </c:if>

    <!-- Role Tabs -->
    <div class="role-tabs">
      <div class="role-tab ${selectedRole == 'admin' || selectedRole == null ? 'active' : ''}"
           onclick="selectRole('admin')">
        <span class="role-icon">🔧</span>Admin
      </div>
      <div class="role-tab ${selectedRole == 'librarian' ? 'active' : ''}"
           onclick="selectRole('librarian')">
        <span class="role-icon">📋</span>Librarian
      </div>
      <div class="role-tab ${selectedRole == 'member' ? 'active' : ''}"
           onclick="selectRole('member')">
        <span class="role-icon">👤</span>Member
      </div>
    </div>

    <!-- Credentials Hint -->
    <div class="credentials-hint" id="hint-admin">
      <span>Admin credentials:</span><br>
      Username: <span>admin1</span> &nbsp;|&nbsp; Password: <span>admin@123</span>
    </div>
    <div class="credentials-hint" id="hint-librarian" style="display:none">
      <span>Librarian credentials:</span><br>
      amit_lib / lib@123 &nbsp;|&nbsp; neha_lib / lib@456<br>
      rahul_lib / lib@789 &nbsp;|&nbsp; priya_lib / lib@321
    </div>
    <div class="credentials-hint" id="hint-member" style="display:none">
      <span>Member credentials:</span><br>
      rohit01 / rohit@123 &nbsp;|&nbsp; ananya01 / ananya@123<br>
      arjun01 / arjun@123 &nbsp;|&nbsp; sneha01 / sneha@123
    </div>

    <!-- Login Form -->
    <form method="post" action="login">
      <input type="hidden" name="role" id="roleInput" value="admin">

      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" placeholder="Enter username"
               value="${param.username}" required autofocus>
      </div>

      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter password" required>
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%;padding:12px">
        Login →
      </button>
    </form>

  </div>

  <div class="login-footer">
    SmartShelf · Group 129 · DBMS Task 5
  </div>

</div>

<script>
  function selectRole(role) {
    document.getElementById('roleInput').value = role;
    document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
    event.target.closest('.role-tab').classList.add('active');
    document.getElementById('hint-admin').style.display     = role === 'admin'     ? 'block' : 'none';
    document.getElementById('hint-librarian').style.display = role === 'librarian' ? 'block' : 'none';
    document.getElementById('hint-member').style.display    = role === 'member'    ? 'block' : 'none';
  }
</script>
</body>
</html>
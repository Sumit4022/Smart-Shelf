<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>History — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">
  <h2>Borrow History</h2>

  <c:if test="${param.error != null}">
    <div class="alert alert-error">❌ ${param.error}</div>
  </c:if>

  <!-- Filter Form -->
  <form method="get" action="history" style="display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap;">
    <select name="memberId" style="background:#1a1e27;border:1px solid #252a36;
            border-radius:8px;padding:8px 14px;color:#e8e4d8;font-size:13px;outline:none;">
      <option value="">All Members</option>
      <c:forEach var="m" items="${memberList}">
        <option value="${m.Member_Id}"
          <c:if test="${param.memberId == m.Member_Id}">selected</c:if>>
          ${m.Name}
        </option>
      </c:forEach>
    </select>

    <select name="status" style="background:#1a1e27;border:1px solid #252a36;
            border-radius:8px;padding:8px 14px;color:#e8e4d8;font-size:13px;outline:none;">
      <option value="">All Status</option>
      <option value="Issued"   <c:if test="${param.status == 'Issued'}">selected</c:if>>Issued</option>
      <option value="Returned" <c:if test="${param.status == 'Returned'}">selected</c:if>>Returned</option>
    </select>

    <button type="submit" class="btn btn-primary">Filter</button>
  </form>

  <!-- History Table -->
  <div class="card">
    <table>
      <thead>
        <tr>
          <th>Borrow ID</th>
          <th>Member</th>
          <th>Book</th>
          <th>Borrow Date</th>
          <th>Due Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <c:choose>
          <c:when test="${empty history}">
            <tr>
              <td colspan="6" style="text-align:center;padding:32px;color:#6b7280;">
                No borrow records found
              </td>
            </tr>
          </c:when>
          <c:otherwise>
            <c:forEach var="h" items="${history}">
              <tr>
                <td>#${h.Borrow_Id}</td>
                <td>${h.member_name}</td>
                <td>${h.book_title}</td>
                <td>${h.Borrow_Date}</td>
                <td>${h.Due_Date}</td>
                <td>
                  <c:choose>
                    <c:when test="${h.Status == 'Issued'}">
                      <span class="badge badge-yellow">Issued</span>
                    </c:when>
                    <c:otherwise>
                      <span class="badge badge-green">Returned</span>
                    </c:otherwise>
                  </c:choose>
                </td>
              </tr>
            </c:forEach>
          </c:otherwise>
        </c:choose>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
```


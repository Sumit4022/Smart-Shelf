<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c"  uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<!DOCTYPE html>
<html>
<head>
  <title>SQL Queries — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .query-grid {
      display: grid;
      grid-template-columns: 320px 1fr;
      gap: 20px;
      align-items: start;
    }
    .query-list { display: flex; flex-direction: column; gap: 8px; }
    .query-item {
      display: block;
      padding: 12px 16px;
      background: #13161d;
      border: 1px solid #252a36;
      border-radius: 10px;
      text-decoration: none;
      color: #e8e4d8;
      font-size: 13px;
      font-weight: 500;
      transition: all 0.15s;
      cursor: pointer;
    }
    .query-item:hover { border-color: #e8c87a; color: #e8c87a; }
    .query-item.active { border-color: #e8c87a; background: rgba(232,200,122,0.08); color: #e8c87a; }
    .query-item .q-type {
      display: inline-block;
      font-size: 10px;
      font-family: monospace;
      font-weight: 700;
      letter-spacing: 0.5px;
      padding: 2px 7px;
      border-radius: 4px;
      margin-right: 8px;
    }
    .type-SELECT { background: rgba(139,232,164,0.15); color: #8be8a4; }
    .type-INSERT { background: rgba(122,184,232,0.15); color: #7ab8e8; }
    .type-UPDATE { background: rgba(232,200,122,0.15); color: #e8c87a; }
    .type-DELETE { background: rgba(232,122,122,0.15); color: #e87a7a; }
    .type-DDL    { background: rgba(180,140,232,0.15); color: #b48ce8; }

    .result-panel { position: sticky; top: 20px; }
    .sql-block {
      background: #0d0f14;
      border: 1px solid #252a36;
      border-radius: 8px;
      padding: 14px 18px;
      font-family: 'Courier New', monospace;
      font-size: 12px;
      color: #8be8a4;
      line-height: 1.7;
      white-space: pre-wrap;
      word-break: break-all;
      margin-bottom: 16px;
    }
    .result-table-wrap { overflow-x: auto; max-height: 400px; overflow-y: auto; border-radius: 8px; border: 1px solid #252a36; }
    .result-table-wrap table { margin: 0; }
    .empty-state {
      display: flex; flex-direction: column; align-items: center;
      justify-content: center; padding: 60px 20px;
      color: #6b7280; text-align: center;
    }
    .empty-state .icon { font-size: 48px; margin-bottom: 16px; }
    .run-btn {
      display: inline-flex; align-items: center; gap: 6px;
      padding: 9px 20px; border-radius: 8px;
      font-size: 13px; font-weight: 600; cursor: pointer;
      border: none; font-family: 'Segoe UI', sans-serif;
      transition: all 0.15s; text-decoration: none;
      background: #e8c87a; color: #0d0f14;
      margin-bottom: 16px;
    }
    .run-btn:hover { background: #d4b06a; }
    .status-ok    { color: #8be8a4; font-size: 13px; font-weight: 600; margin-bottom: 12px; }
    .status-error { color: #e87a7a; font-size: 13px; font-weight: 600; margin-bottom: 12px; }
    .stat-pill {
      display: inline-flex; align-items: center; gap: 6px;
      background: rgba(232,200,122,0.1); border: 1px solid rgba(232,200,122,0.2);
      color: #e8c87a; border-radius: 20px; padding: 4px 12px;
      font-size: 11px; font-family: monospace; margin-bottom: 16px;
    }
    .header-row {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">

  <div class="header-row">
    <div>
      <h2 style="margin-bottom:4px">🗄️ SQL Query Explorer</h2>
      <span style="font-family:monospace;font-size:12px;color:#6b7280;
                   text-transform:uppercase;letter-spacing:1px">
        Task 4 — 21 Queries Demonstrated
      </span>
    </div>
    <div class="stat-pill">📋 21 Queries &nbsp;|&nbsp; SELECT · INSERT · UPDATE · DELETE · DDL</div>
  </div>

  <c:if test="${not empty dbError}">
    <div class="alert alert-error">❌ Database Error: ${dbError}</div>
  </c:if>

  <div class="query-grid">

    <!-- LEFT: Query List -->
    <div class="query-list">
      <c:forEach var="q" items="${queries}">
        <a href="querydemo?run=${q.index}"
           class="query-item <c:if test='${runIndex == String.valueOf(q.index)}'>active</c:if>"
           style="<c:if test='${runIndex != null && runIndex == String.valueOf(q.index)}'>border-color:#e8c87a;background:rgba(232,200,122,0.08);color:#e8c87a;</c:if>">
          <span class="q-type type-${q.type}">${q.type}</span>
          ${q.title}
        </a>
      </c:forEach>
    </div>

    <!-- RIGHT: Result Panel -->
    <div class="result-panel card" style="padding:24px">

      <c:choose>
        <%-- No query selected yet --%>
        <c:when test="${runIndex == null}">
          <div class="empty-state">
            <div class="icon">🔍</div>
            <div style="font-size:15px;font-weight:600;margin-bottom:8px;color:#e8e4d8">
              Select a query to run
            </div>
            <div style="font-size:13px;line-height:1.6">
              Click any query on the left to execute it against the SmartShelf database
              and see the results here.
            </div>
          </div>
        </c:when>

        <%-- A query is selected --%>
        <c:otherwise>
          <c:forEach var="q" items="${queries}">
            <c:if test="${runIndex == String.valueOf(q.index)}">

              <h3 style="margin-bottom:4px">${q.title}</h3>
              <p style="font-size:13px;color:#6b7280;margin-bottom:16px">${q.desc}</p>

              <!-- SQL Display -->
              <div class="sql-block">${q.sql}</div>

              <!-- Run / Re-run button -->
              <a href="querydemo?run=${q.index}" class="run-btn">▶ Run Query</a>

              <!-- Results -->
              <c:choose>
                <c:when test="${q.status == 'ok'}">

                  <c:choose>
                    <%-- SELECT result --%>
                    <c:when test="${not empty q.results}">
                      <div class="status-ok">
                        ✅ ${q.type} executed — ${fn:length(q.results)} row(s) returned
                      </div>
                      <div class="result-table-wrap">
                        <table>
                          <thead>
                            <tr>
                              <c:forEach var="col" items="${q.results[0]}">
                                <th>${col.key}</th>
                              </c:forEach>
                            </tr>
                          </thead>
                          <tbody>
                            <c:forEach var="row" items="${q.results}">
                              <tr>
                                <c:forEach var="cell" items="${row}">
                                  <td>
                                    <c:choose>
                                      <c:when test="${cell.value == null}">
                                        <span style="color:#6b7280;font-style:italic">NULL</span>
                                      </c:when>
                                      <c:when test="${cell.key == 'Status' && cell.value == 'Issued'}">
                                        <span class="badge badge-yellow">${cell.value}</span>
                                      </c:when>
                                      <c:when test="${cell.key == 'Status' && cell.value == 'Returned'}">
                                        <span class="badge badge-green">${cell.value}</span>
                                      </c:when>
                                      <c:when test="${cell.key == 'Paid_Status' && cell.value == 'Unpaid'}">
                                        <span class="badge badge-red">${cell.value}</span>
                                      </c:when>
                                      <c:when test="${cell.key == 'Paid_Status' && cell.value == 'Paid'}">
                                        <span class="badge badge-green">${cell.value}</span>
                                      </c:when>
                                      <c:when test="${cell.key == 'Genre_Type' || cell.key == 'Location'}">
                                        <span class="badge">${cell.value}</span>
                                      </c:when>
                                      <c:otherwise>${cell.value}</c:otherwise>
                                    </c:choose>
                                  </td>
                                </c:forEach>
                              </tr>
                            </c:forEach>
                          </tbody>
                        </table>
                      </div>
                    </c:when>

                    <%-- SELECT returned 0 rows --%>
                    <c:when test="${q.type == 'SELECT' && empty q.results}">
                      <div class="status-ok">✅ Query executed — 0 rows returned</div>
                      <div style="text-align:center;padding:24px;color:#6b7280">No data found</div>
                    </c:when>

                    <%-- Non-SELECT success --%>
                    <c:otherwise>
                      <div class="status-ok">✅ ${q.affected}</div>
                      <div style="background:#0d0f14;border:1px solid #252a36;border-radius:8px;
                                  padding:20px;text-align:center;color:#8be8a4;font-size:13px">
                        ${q.type} statement executed successfully against SmartShelfDB.
                      </div>
                    </c:otherwise>
                  </c:choose>

                </c:when>

                <%-- Error state --%>
                <c:when test="${q.status == 'error'}">
                  <div class="status-error">❌ Error executing query</div>
                  <div style="background:rgba(232,122,122,0.08);border:1px solid rgba(232,122,122,0.2);
                              border-radius:8px;padding:14px;font-size:12px;
                              font-family:monospace;color:#e87a7a">
                    ${q.error}
                  </div>
                </c:when>

              </c:choose>

            </c:if>
          </c:forEach>
        </c:otherwise>
      </c:choose>

    </div>
  </div>
</div>
</body>
</html>

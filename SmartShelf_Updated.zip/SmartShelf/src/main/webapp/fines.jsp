<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>Fines — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">
  <h2>Fine Records</h2>

  <c:if test="${param.success != null}">
    <div class="alert alert-success">✅ ${param.success}</div>
  </c:if>

  <div class="card">
    <table>
      <thead>
        <tr>
          <th>Fine ID</th><th>Member</th><th>Book</th>
          <th>Amount</th><th>Due Date</th><th>Status</th><th>Action</th>
        </tr>
      </thead>
      <tbody>
        <c:forEach var="f" items="${fines}">
          <tr>
            <td>#${f.Fine_Id}</td>
            <td>${f.member_name}</td>
            <td>${f.book_title}</td>
            <td style="color:#e87a7a;font-weight:700">₹${f.Amount}</td>
            <td style="font-size:12px">${f.Fine_Due_Date}</td>
            <td>
              <c:choose>
                <c:when test="${f.Paid_Status == 'Paid'}">
                  <span class="badge badge-green">Paid</span>
                </c:when>
                <c:otherwise>
                  <span class="badge badge-red">Unpaid</span>
                </c:otherwise>
              </c:choose>
            </td>
            <td>
              <c:if test="${f.Paid_Status == 'Unpaid'}">
                <form method="post" action="fines" style="display:inline">
                  <input type="hidden" name="fineId" value="${f.Fine_Id}">
                  <button class="btn btn-ghost btn-sm">Mark Paid</button>
                </form>
              </c:if>
            </td>
          </tr>
        </c:forEach>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
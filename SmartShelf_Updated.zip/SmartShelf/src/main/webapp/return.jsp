<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
  <title>Return Book — SmartShelf</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
<%@ include file="navbar.jsp" %>
<div class="container">
  <h2>Return Book</h2>

  <c:if test="${param.success != null}">
    <div class="alert alert-success">✅ ${param.success}</div>
  </c:if>
  <c:if test="${param.error != null}">
    <div class="alert alert-error">❌ ${param.error}</div>
  </c:if>

  <div class="card" style="max-width:520px">
    <form method="post" action="return">

      <div class="form-group">
        <label>Select Borrow Record</label>
        <select name="borrowId" required>
          <option value="">-- Select Record --</option>
          <c:forEach var="b" items="${borrows}">
            <option value="${b.Borrow_Id}">
              #${b.Borrow_Id} — ${b.member_name} → ${b.book_title} (Due: ${b.Due_Date})
            </option>
          </c:forEach>
        </select>
      </div>

      <div class="trigger-info">
        ⚡ Active triggers: generate_fine (if overdue) · increase_quantity_on_return
      </div>

      <button type="submit" class="btn btn-primary" style="width:100%">
        ⬇️ Return Book
      </button>
    </form>
  </div>
</div>
</body>
</html>
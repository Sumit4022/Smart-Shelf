package com.smartshelf.filters;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/*")
public class AuthFilter implements Filter {

    // Pages that don't need login
    private static final String[] PUBLIC_URLS = {
        "/login", "/logout", "/css/", "/images/"
    };

    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest)  req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getServletPath();

        // Allow public URLs through
        for (String url : PUBLIC_URLS) {
            if (path.startsWith(url)) {
                chain.doFilter(req, res);
                return;
            }
        }

        // Check session
        HttpSession session = request.getSession(false);
        boolean loggedIn = (session != null && session.getAttribute("role") != null);

        if (!loggedIn) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        // Role-based page restrictions
        String role = (String) session.getAttribute("role");

        // Members can only see their dashboard and books
        if ("member".equals(role)) {
            if (path.equals("/issue") || path.equals("/return") ||
                path.equals("/members") || path.equals("/triggerdemo") ||
                path.equals("/fines")) {
                response.sendRedirect(request.getContextPath() + "/dashboard");
                return;
            }
        }

        // Librarians cannot access admin-only pages
        if ("librarian".equals(role)) {
            if (path.equals("/members") || path.equals("/triggerdemo")) {
                response.sendRedirect(request.getContextPath() + "/dashboard");
                return;
            }
        }

        chain.doFilter(req, res);
    }

    public void init(FilterConfig config) {}
    public void destroy() {}
}
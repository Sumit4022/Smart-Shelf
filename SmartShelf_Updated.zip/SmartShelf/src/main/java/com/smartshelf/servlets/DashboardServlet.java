package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // Check login
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("role") == null) {
            res.sendRedirect("login");
            return;
        }

        String role = (String) session.getAttribute("role");

        try (Connection conn = DBConnection.getConnection()) {

            // Stats for all roles
            ResultSet totalBooks = conn.createStatement()
                .executeQuery("SELECT COUNT(*) AS cnt FROM book");
            totalBooks.next();
            req.setAttribute("totalBooks", totalBooks.getInt("cnt"));

            ResultSet totalMembers = conn.createStatement()
                .executeQuery("SELECT COUNT(*) AS cnt FROM member");
            totalMembers.next();
            req.setAttribute("totalMembers", totalMembers.getInt("cnt"));

            ResultSet totalIssued = conn.createStatement()
                .executeQuery("SELECT COUNT(*) AS cnt FROM book_info WHERE Status='Issued'");
            totalIssued.next();
            req.setAttribute("totalIssued", totalIssued.getInt("cnt"));

            ResultSet totalFines = conn.createStatement()
                .executeQuery("SELECT COALESCE(SUM(Amount),0) AS amt FROM fine WHERE Paid_Status='Unpaid'");
            totalFines.next();
            req.setAttribute("totalFines", totalFines.getDouble("amt"));

            // Member-specific: their own borrow history
            if ("member".equals(role)) {
                int memberId = (int) session.getAttribute("userId");
                ResultSet myBooks = conn.createStatement()
                    .executeQuery(
                        "SELECT b.Title, bi.Borrow_Date, bi.Due_Date, bi.Status " +
                        "FROM book_info bi " +
                        "JOIN book b ON bi.Book_Id = b.Book_Id " +
                        "WHERE bi.Member_Id=" + memberId +
                        " ORDER BY bi.Borrow_Date DESC");
                req.setAttribute("myBooks", DBConnection.toList(myBooks));

                ResultSet myFines = conn.createStatement()
                    .executeQuery(
                        "SELECT f.Amount, f.Paid_Status, b.Title " +
                        "FROM fine f " +
                        "JOIN book_info bi ON f.Borrow_Id = bi.Borrow_Id " +
                        "JOIN book b ON bi.Book_Id = b.Book_Id " +
                        "WHERE bi.Member_Id=" + memberId);
                req.setAttribute("myFines", DBConnection.toList(myFines));
            }

            // Recent activity for admin and librarian
            if ("admin".equals(role) || "librarian".equals(role)) {
                ResultSet recent = conn.createStatement()
                    .executeQuery(
                        "SELECT m.Name AS member_name, b.Title AS book_title, " +
                        "bi.Borrow_Date, bi.Status " +
                        "FROM book_info bi " +
                        "JOIN member m ON bi.Member_Id = m.Member_Id " +
                        "JOIN book b ON bi.Book_Id = b.Book_Id " +
                        "ORDER BY bi.Borrow_Date DESC LIMIT 5");
                req.setAttribute("recentActivity", DBConnection.toList(recent));

                ResultSet unpaidFines = conn.createStatement()
                    .executeQuery(
                        "SELECT m.Name AS member_name, f.Amount " +
                        "FROM fine f " +
                        "JOIN book_info bi ON f.Borrow_Id = bi.Borrow_Id " +
                        "JOIN member m ON bi.Member_Id = m.Member_Id " +
                        "WHERE f.Paid_Status='Unpaid' " +
                        "ORDER BY f.Fine_Id DESC LIMIT 5");
                req.setAttribute("unpaidFines", DBConnection.toList(unpaidFines));
            }

        } catch (SQLException e) {
            req.setAttribute("error", e.getMessage());
        }

        req.getRequestDispatcher("/dashboard.jsp").forward(req, res);
    }
}
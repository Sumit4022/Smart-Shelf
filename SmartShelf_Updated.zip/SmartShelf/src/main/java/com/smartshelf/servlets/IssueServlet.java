package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

@WebServlet("/issue")
public class IssueServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	        throws ServletException, IOException {
	    try (Connection conn = DBConnection.getConnection()) {

	        ResultSet members = conn.createStatement()
	            .executeQuery("SELECT Member_Id, Name FROM member");
	        req.setAttribute("members", DBConnection.toList(members));

	        ResultSet books = conn.createStatement()
	            .executeQuery("SELECT Book_Id, Title, Quantity FROM book WHERE Quantity > 0");
	        req.setAttribute("books", DBConnection.toList(books));

	        ResultSet librarians = conn.createStatement()
	            .executeQuery("SELECT Librarian_Id, Name FROM librarian");
	        req.setAttribute("librarians", DBConnection.toList(librarians));

	    } catch (SQLException e) {
	        req.setAttribute("error", e.getMessage());
	    }
	    req.getRequestDispatcher("/issue.jsp").forward(req, res);
	}

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        int memberId    = Integer.parseInt(req.getParameter("memberId"));
        int bookId      = Integer.parseInt(req.getParameter("bookId"));
        int librarianId = Integer.parseInt(req.getParameter("librarianId"));

        try (Connection conn = DBConnection.getConnection()) {
            // INSERT fires 3 triggers in MySQL automatically:
            // 1. check_max_books          - BEFORE INSERT
            // 2. check_book_availability  - BEFORE INSERT
            // 3. reduce_quantity_on_issue - AFTER INSERT
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO book_info " +
                "(Borrow_Date, Borrow_Time, Due_Date, Status, Librarian_Id, Member_Id, Book_Id) " +
                "VALUES (CURDATE(), CURTIME(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Issued', ?, ?, ?)");

            ps.setInt(1, librarianId);
            ps.setInt(2, memberId);
            ps.setInt(3, bookId);
            ps.executeUpdate();

            res.sendRedirect("issue?success=Book+issued+successfully");

        } catch (SQLException e) {
            // Trigger SIGNAL errors come here
            res.sendRedirect("issue?error=" + e.getMessage());
        }
    }
}
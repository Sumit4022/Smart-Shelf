package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

@WebServlet("/members")
public class MemberServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	        throws ServletException, IOException {
	    try (Connection conn = DBConnection.getConnection()) {

	        ResultSet rs = conn.createStatement().executeQuery(
	            "SELECT m.Member_Id, m.Name, m.Email_Id, m.Phone_Number, " +
	            "m.Membership_Expiry, ms.Membership_Type_Id " +
	            "FROM member m " +
	            "JOIN membership ms ON m.Membership_Type_Id = ms.Membership_Type_Id " +
	            "ORDER BY m.Member_Id");
	        req.setAttribute("members", DBConnection.toList(rs));

	    } catch (SQLException e) {
	        req.setAttribute("error", e.getMessage());
	    }
	    req.getRequestDispatcher("/members.jsp").forward(req, res);
	}
}
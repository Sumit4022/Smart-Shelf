package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

@WebServlet("/history")
public class HistoryServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	        throws ServletException, IOException {

	    String memberId = req.getParameter("memberId");
	    String status   = req.getParameter("status");

	    try (Connection conn = DBConnection.getConnection()) {

	        ResultSet memberList = conn.createStatement()
	            .executeQuery("SELECT Member_Id, Name FROM member");
	        req.setAttribute("memberList", DBConnection.toList(memberList));

	        String sql =
	            "SELECT bi.Borrow_Id, m.Name AS member_name, b.Title AS book_title, " +
	            "bi.Borrow_Date, bi.Due_Date, bi.Status " +
	            "FROM book_info bi " +
	            "JOIN member m ON bi.Member_Id = m.Member_Id " +
	            "JOIN book b ON bi.Book_Id = b.Book_Id WHERE 1=1";

	        if (memberId != null && !memberId.isEmpty())
	            sql += " AND bi.Member_Id = " + memberId;
	        if (status != null && !status.isEmpty())
	            sql += " AND bi.Status = '" + status + "'";

	        sql += " ORDER BY bi.Borrow_Date DESC";

	        ResultSet history = conn.createStatement().executeQuery(sql);
	        req.setAttribute("history", DBConnection.toList(history));

	    } catch (SQLException e) {
	        req.setAttribute("error", e.getMessage());
	    }
	    req.getRequestDispatcher("/history.jsp").forward(req, res);
	}
}
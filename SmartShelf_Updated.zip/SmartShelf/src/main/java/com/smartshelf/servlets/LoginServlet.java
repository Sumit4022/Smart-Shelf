package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        // If already logged in, redirect to dashboard
        HttpSession session = req.getSession(false);
        if (session != null && session.getAttribute("role") != null) {
            res.sendRedirect("dashboard");
            return;
        }
        req.getRequestDispatcher("/login.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String role     = req.getParameter("role");

        try (Connection conn = DBConnection.getConnection()) {

            ResultSet rs = null;
            String name  = null;
            int    id    = -1;

            if ("admin".equals(role)) {
                PreparedStatement ps = conn.prepareStatement(
                    "SELECT Admin_Id, Name FROM admin " +
                    "WHERE Username=? AND Password=?");
                ps.setString(1, username);
                ps.setString(2, password);
                rs = ps.executeQuery();
                if (rs.next()) {
                    id   = rs.getInt("Admin_Id");
                    name = rs.getString("Name");
                }

            } else if ("librarian".equals(role)) {
                PreparedStatement ps = conn.prepareStatement(
                    "SELECT Librarian_Id, Name FROM librarian " +
                    "WHERE Username=? AND Password=?");
                ps.setString(1, username);
                ps.setString(2, password);
                rs = ps.executeQuery();
                if (rs.next()) {
                    id   = rs.getInt("Librarian_Id");
                    name = rs.getString("Name");
                }

            } else if ("member".equals(role)) {
                PreparedStatement ps = conn.prepareStatement(
                    "SELECT Member_Id, Name FROM member " +
                    "WHERE Username=? AND Password=?");
                ps.setString(1, username);
                ps.setString(2, password);
                rs = ps.executeQuery();
                if (rs.next()) {
                    id   = rs.getInt("Member_Id");
                    name = rs.getString("Name");
                }
            }

            if (name != null) {
                // Login success — create session
                HttpSession session = req.getSession(true);
                session.setAttribute("role",     role);
                session.setAttribute("name",     name);
                session.setAttribute("userId",   id);
                session.setAttribute("username", username);
                res.sendRedirect("dashboard");
            } else {
                // Login failed
                req.setAttribute("error", "Invalid username or password");
                req.setAttribute("selectedRole", role);
                req.getRequestDispatcher("/login.jsp").forward(req, res);
            }

        } catch (SQLException e) {
            req.setAttribute("error", "Database error: " + e.getMessage());
            req.getRequestDispatcher("/login.jsp").forward(req, res);
        }
    }
}
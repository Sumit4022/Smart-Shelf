package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/querydemo")
public class QueryDemoServlet extends HttpServlet {

    // ── All 21 queries from Task 4 ──────────────────────────────────────────
    private static final String[][] QUERIES = {
        {
            "1. View All Books",
            "View all books in the library with title, author, genre and quantity.",
            "SELECT Title, Author, Genre_Type, Quantity FROM book"
        },
        {
            "2. Books by Specific Author",
            "Show books written by 'Robert C. Martin'.",
            "SELECT Title, Author FROM book WHERE Author = 'Robert C. Martin'"
        },
        {
            "3. Books with Shelf Location",
            "List all books along with their shelf location using JOINs.",
            "SELECT b.Title, g.Genre_Type, s.Location " +
            "FROM book b " +
            "JOIN genre g ON b.Genre_Type = g.Genre_Type " +
            "JOIN shelf s ON g.Shelf_Number = s.Shelf_Number"
        },
        {
            "4. Books Issued to Members",
            "Display all books currently or previously issued to members.",
            "SELECT m.Name, b.Title, bi.Borrow_Date " +
            "FROM book_info bi " +
            "JOIN member m ON bi.Member_Id = m.Member_Id " +
            "JOIN book b ON bi.Book_Id = b.Book_Id"
        },
        {
            "5. Members with Membership Type",
            "List all members along with their membership plan.",
            "SELECT m.Name, m.Email_Id, ms.Membership_Type_Id " +
            "FROM member m " +
            "JOIN membership ms ON m.Membership_Type_Id = ms.Membership_Type_Id"
        },
        {
            "6. Currently Issued Books (Subquery)",
            "Find books that are currently issued using a subquery.",
            "SELECT Title FROM book " +
            "WHERE Book_Id IN (SELECT Book_Id FROM book_info WHERE Status = 'Issued')"
        },
        {
            "7. Books with Quantity > 3",
            "Find books with more than 3 copies available.",
            "SELECT Title, Quantity FROM book WHERE Quantity > 3"
        },
        {
            "8. Book Count per Genre",
            "Count total number of books in each genre using GROUP BY.",
            "SELECT Genre_Type, COUNT(*) AS Total_Books FROM book GROUP BY Genre_Type"
        },
        {
            "9. Unpaid Fines",
            "Show all unpaid fines with amount and due date.",
            "SELECT Fine_Id, Amount, Fine_Due_Date FROM fine WHERE Paid_Status = 'Unpaid'"
        },
        {
            "10. Total Fines Collected",
            "Find total fine amount collected from paid fines using SUM.",
            "SELECT SUM(Amount) AS Total_Fine_Collected FROM fine WHERE Paid_Status = 'Paid'"
        },
        {
            "11. Most Borrowed Book",
            "Find the most borrowed book using GROUP BY + ORDER BY + LIMIT.",
            "SELECT Book_Id, COUNT(*) AS Borrow_Count " +
            "FROM book_info GROUP BY Book_Id ORDER BY Borrow_Count DESC LIMIT 1"
        },
        {
            "12. Librarian Managing Most Books",
            "Find the librarian managing the highest number of books.",
            "SELECT Librarian_Id, COUNT(*) AS Books_Managed " +
            "FROM book GROUP BY Librarian_Id ORDER BY Books_Managed DESC LIMIT 1"
        },
        {
            "13. All Members & Borrowed Books (LEFT JOIN)",
            "Show all members and the books they borrowed, including members who haven't borrowed.",
            "SELECT m.Name, b.Title, bi.Borrow_Date " +
            "FROM member m " +
            "LEFT JOIN book_info bi ON m.Member_Id = bi.Member_Id " +
            "LEFT JOIN book b ON bi.Book_Id = b.Book_Id"
        },
        {
            "14. Books with Shelf Numbers (NATURAL JOIN)",
            "Display books and their shelf numbers using NATURAL JOIN.",
            "SELECT Title, Genre_Type, Shelf_Number FROM book NATURAL JOIN genre"
        },
        {
            "15. Books per Librarian",
            "Count books managed by each librarian.",
            "SELECT Librarian_Id, COUNT(Book_Id) AS Total_Books FROM book GROUP BY Librarian_Id"
        },
        {
            "16. Librarians with More Than One Book (HAVING)",
            "Find librarians managing more than one book using HAVING clause.",
            "SELECT Librarian_Id, COUNT(Book_Id) AS Total_Books " +
            "FROM book GROUP BY Librarian_Id HAVING COUNT(Book_Id) > 1"
        },
        {
            "17. Reservations per Book",
            "Count number of reservations for each book.",
            "SELECT b.Title, COUNT(r.Reservation_Id) AS Total_Reservations " +
            "FROM book b LEFT JOIN reservation r ON b.Book_Id = r.Book_Id GROUP BY b.Title"
        },
        {
            "18. Insert New Book",
            "Insert a new book 'Artificial Intelligence' by Stuart Russell.",
            "INSERT INTO book (Title, Author, Publisher, ISBN, Genre_Type, Librarian_Id, Quantity) " +
            "VALUES ('Artificial Intelligence', 'Stuart Russell', 'Pearson', 'ISBN008', 'Technology', 2, 3)"
        },
        {
            "19. Update Book Quantity",
            "Update quantity of 'Clean Code' to 10.",
            "UPDATE book SET Quantity = 10 WHERE Title = 'Clean Code'"
        },
        {
            "20. Delete a Reservation",
            "Delete reservation with ID = 4.",
            "DELETE FROM reservation WHERE Reservation_Id = 4"
        },
        {
            "21. Create View: Borrowed_Books",
            "Create a reusable view for all borrowed books.",
            "CREATE OR REPLACE VIEW Borrowed_Books AS " +
            "SELECT m.Name, b.Title, bi.Borrow_Date " +
            "FROM book_info bi " +
            "JOIN member m ON bi.Member_Id = m.Member_Id " +
            "JOIN book b ON bi.Book_Id = b.Book_Id"
        }
    };

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String run = req.getParameter("run");   // e.g. "0", "1", ...
        List<Map<String, Object>> queryMeta = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection()) {

            for (int i = 0; i < QUERIES.length; i++) {
                Map<String, Object> qm = new LinkedHashMap<>();
                qm.put("index",   i);
                qm.put("title",   QUERIES[i][0]);
                qm.put("desc",    QUERIES[i][1]);
                qm.put("sql",     QUERIES[i][2]);

                // Determine query type
                String sqlUpper = QUERIES[i][2].trim().toUpperCase();
                String type = sqlUpper.startsWith("SELECT") ? "SELECT" :
                              sqlUpper.startsWith("INSERT") ? "INSERT" :
                              sqlUpper.startsWith("UPDATE") ? "UPDATE" :
                              sqlUpper.startsWith("DELETE") ? "DELETE" :
                              sqlUpper.startsWith("CREATE") ? "DDL"    : "OTHER";
                qm.put("type", type);

                // Run this query if requested
                if (String.valueOf(i).equals(run)) {
                    try {
                        if ("SELECT".equals(type)) {
                            ResultSet rs = conn.createStatement().executeQuery(QUERIES[i][2]);
                            qm.put("results", DBConnection.toList(rs));
                            qm.put("status", "ok");
                        } else {
                            conn.createStatement().executeUpdate(QUERIES[i][2]);
                            qm.put("status", "ok");
                            qm.put("affected", "Query executed successfully ✓");
                        }
                    } catch (SQLException ex) {
                        qm.put("status", "error");
                        qm.put("error", ex.getMessage());
                    }
                }

                queryMeta.add(qm);
            }

        } catch (SQLException e) {
            req.setAttribute("dbError", e.getMessage());
        }

        req.setAttribute("queries", queryMeta);
        req.setAttribute("runIndex", run);
        req.getRequestDispatcher("/querydemo.jsp").forward(req, res);
    }
}

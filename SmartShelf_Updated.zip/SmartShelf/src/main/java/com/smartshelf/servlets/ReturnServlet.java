package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

@WebServlet("/return")
public class ReturnServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	        throws ServletException, IOException {
	    try (Connection conn = DBConnection.getConnection()) {

	        ResultSet rs = conn.createStatement().executeQuery(
	            "SELECT bi.Borrow_Id, m.Name AS member_name, " +
	            "b.Title AS book_title, bi.Due_Date " +
	            "FROM book_info bi " +
	            "JOIN member m ON bi.Member_Id = m.Member_Id " +
	            "JOIN book b ON bi.Book_Id = b.Book_Id " +
	            "WHERE bi.Status = 'Issued'");
	        req.setAttribute("borrows", DBConnection.toList(rs));

	    } catch (SQLException e) {
	        req.setAttribute("error", e.getMessage());
	    }
	    req.getRequestDispatcher("/return.jsp").forward(req, res);
	}

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        int borrowId = Integer.parseInt(req.getParameter("borrowId"));

        try (Connection conn = DBConnection.getConnection()) {
            // UPDATE fires 2 triggers automatically:
            // 1. generate_fine               - AFTER UPDATE (if overdue)
            // 2. increase_quantity_on_return - AFTER UPDATE
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE book_info SET Status='Returned' WHERE Borrow_Id=?");
            ps.setInt(1, borrowId);
            ps.executeUpdate();

            res.sendRedirect("return?success=Book+returned+successfully");

        } catch (SQLException e) {
            res.sendRedirect("return?error=" + e.getMessage());
        }
    }
}
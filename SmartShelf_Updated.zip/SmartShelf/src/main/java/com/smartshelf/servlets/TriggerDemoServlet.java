package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/triggerdemo")
public class TriggerDemoServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // Load current book and member data for display
        try (Connection conn = DBConnection.getConnection()) {

            ResultSet books = conn.createStatement()
                .executeQuery("SELECT Book_Id, Title, Quantity FROM book ORDER BY Book_Id");
            req.setAttribute("books", DBConnection.toList(books));

            ResultSet members = conn.createStatement()
                .executeQuery(
                    "SELECT mb.Member_Id, mb.Name, m.Max_Book_Allowed, " +
                    "COUNT(bi.Borrow_Id) AS Current_Count " +
                    "FROM member mb " +
                    "JOIN membership m ON mb.Membership_Type_Id = m.Membership_Type_Id " +
                    "LEFT JOIN book_info bi ON mb.Member_Id = bi.Member_Id AND bi.Status = 'Issued' " +
                    "GROUP BY mb.Member_Id, mb.Name, m.Max_Book_Allowed");
            req.setAttribute("members", DBConnection.toList(members));

            ResultSet fines = conn.createStatement()
                .executeQuery(
                    "SELECT f.Fine_Id, m.Name AS member_name, f.Amount, f.Paid_Status " +
                    "FROM fine f " +
                    "JOIN book_info bi ON f.Borrow_Id = bi.Borrow_Id " +
                    "JOIN member m ON bi.Member_Id = m.Member_Id " +
                    "ORDER BY f.Fine_Id DESC");
            req.setAttribute("fines", DBConnection.toList(fines));

            ResultSet issued = conn.createStatement()
                .executeQuery(
                    "SELECT bi.Borrow_Id, m.Name AS member_name, b.Title AS book_title, bi.Due_Date " +
                    "FROM book_info bi " +
                    "JOIN member m ON bi.Member_Id = m.Member_Id " +
                    "JOIN book b ON bi.Book_Id = b.Book_Id " +
                    "WHERE bi.Status = 'Issued'");
            req.setAttribute("issued", DBConnection.toList(issued));

        } catch (SQLException e) {
            req.setAttribute("error", e.getMessage());
        }

        req.getRequestDispatcher("/triggerdemo.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        String result = "";
        String status = "success";

        try (Connection conn = DBConnection.getConnection()) {

        	if ("test_availability".equals(action)) {
        	    // Set book to 0
        	    conn.createStatement()
        	        .executeUpdate("UPDATE book SET Quantity = 0 WHERE Book_Id = 7");

        	    try {
        	        PreparedStatement ps = conn.prepareStatement(
        	            "INSERT INTO book_info " +
        	            "(Borrow_Date, Borrow_Time, Due_Date, Status, Librarian_Id, Member_Id, Book_Id) " +
        	            "VALUES (CURDATE(), CURTIME(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Issued', 1, 3, 7)");
        	        ps.executeUpdate();
        	        result = "❌ Trigger did NOT fire — something is wrong!";
        	        status = "fail";
        	    } catch (SQLException triggerErr) {
        	        // DO NOT restore quantity yet — let TA see 0 in the live table
        	        result = "✅ TRIGGER FIRED: check_book_availability → \"" + 
        	                 triggerErr.getMessage() + "\" | " +
        	                 "Check Live Book Quantities below — Linear Algebra Done Right now shows 0. " +
        	                 "No row was inserted into book_info. Click Reset DB to restore.";
        	        status = "success";
        	    }
        	}

            // ── TEST 2: check_max_books ──────────────────────────────────
            else if ("test_maxbooks".equals(action)) {
                // Ananya Singh (Member 2) is on Plan 1 — max 2 books
                // First clear her current issues and give her exactly 2
                conn.createStatement()
                    .executeUpdate("UPDATE book_info SET Status='Returned' WHERE Member_Id=2 AND Status='Issued'");
                conn.createStatement()
                    .executeUpdate("UPDATE book SET Quantity = Quantity + (SELECT COUNT(*) FROM (SELECT * FROM book_info WHERE Member_Id=2) t)");

                // Issue 2 books to fill her limit
                conn.createStatement().executeUpdate(
                    "INSERT INTO book_info (Borrow_Date,Borrow_Time,Due_Date,Status,Librarian_Id,Member_Id,Book_Id) " +
                    "VALUES (CURDATE(),CURTIME(),DATE_ADD(CURDATE(),INTERVAL 14 DAY),'Issued',1,2,1)");
                conn.createStatement().executeUpdate(
                    "INSERT INTO book_info (Borrow_Date,Borrow_Time,Due_Date,Status,Librarian_Id,Member_Id,Book_Id) " +
                    "VALUES (CURDATE(),CURTIME(),DATE_ADD(CURDATE(),INTERVAL 14 DAY),'Issued',1,2,2)");

                // Now try a 3rd book — trigger should block it
                try {
                    conn.createStatement().executeUpdate(
                        "INSERT INTO book_info (Borrow_Date,Borrow_Time,Due_Date,Status,Librarian_Id,Member_Id,Book_Id) " +
                        "VALUES (CURDATE(),CURTIME(),DATE_ADD(CURDATE(),INTERVAL 14 DAY),'Issued',1,2,5)");
                    result = "❌ Trigger did NOT fire — something is wrong!";
                    status = "fail";
                } catch (SQLException triggerErr) {
                    result = "✅ TRIGGER FIRED: check_max_books → \"" + triggerErr.getMessage() + "\"";
                    status = "success";
                }
            }

            // ── TEST 3: reduce_quantity_on_issue ─────────────────────────
            else if ("test_reduce".equals(action)) {

                // Step 1 — Return any existing issued copies of Sapiens
                conn.createStatement().executeUpdate(
                    "UPDATE book_info SET Status='Returned' " +
                    "WHERE Book_Id=5 AND Status='Issued'");

                // Step 2 — Hard reset Sapiens to exactly 5
                conn.createStatement().executeUpdate(
                    "UPDATE book SET Quantity=5 WHERE Book_Id=5");

                // Step 3 — Confirm quantity before (will always be 5 now)
                ResultSet before = conn.createStatement()
                    .executeQuery("SELECT Quantity FROM book WHERE Book_Id=5");
                before.next();
                int qtyBefore = before.getInt("Quantity");

                // Step 4 — Issue Sapiens to Sneha Gupta (Member ID 4)
                // ONLY this one INSERT fires — trigger reduces qty by exactly 1
                conn.createStatement().executeUpdate(
                    "INSERT INTO book_info " +
                    "(Borrow_Date, Borrow_Time, Due_Date, Status, Librarian_Id, Member_Id, Book_Id) " +
                    "VALUES (CURDATE(), CURTIME(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), " +
                    "'Issued', 1, 4, 5)");

                // Step 5 — Confirm quantity after
                ResultSet after = conn.createStatement()
                    .executeQuery("SELECT Quantity FROM book WHERE Book_Id=5");
                after.next();
                int qtyAfter = after.getInt("Quantity");

                result = "✅ TRIGGER FIRED: reduce_quantity_on_issue → " +
                         "Sapiens quantity changed from " + qtyBefore +
                         " → " + qtyAfter +
                         " (reduced by exactly 1 automatically, no UPDATE in Java code!)";
                status = "success";
            }
      

            // ── TEST 4: increase_quantity_on_return ──────────────────────
            else if ("test_increase".equals(action)) {

                // Look specifically for Sapiens (Book ID 5) issued record
                ResultSet rs = conn.createStatement()
                    .executeQuery(
                        "SELECT bi.Borrow_Id, bi.Book_Id, b.Title, b.Quantity " +
                        "FROM book_info bi " +
                        "JOIN book b ON bi.Book_Id = b.Book_Id " +
                        "WHERE bi.Status='Issued' AND bi.Book_Id=5 " +
                        "LIMIT 1");

                if (!rs.next()) {
                    result = "⚠️ Sapiens not currently issued. Run Test 3 first.";
                    status = "warn";
                } else {
                    int borrowId  = rs.getInt("Borrow_Id");
                    int qtyBefore = rs.getInt("Quantity");
                    String title  = rs.getString("Title");

                    // Return it — trigger fires automatically
                    conn.createStatement().executeUpdate(
                        "UPDATE book_info SET Status='Returned' WHERE Borrow_Id=" + borrowId);

                    // Get quantity after
                    ResultSet after = conn.createStatement()
                        .executeQuery("SELECT Quantity FROM book WHERE Book_Id=5");
                    after.next();
                    int qtyAfter = after.getInt("Quantity");

                    result = "✅ TRIGGER FIRED: increase_quantity_on_return → " +
                             "\"" + title + "\" quantity changed from " + qtyBefore +
                             " → " + qtyAfter +
                             " (increased by 1 automatically, no UPDATE in Java code!)";
                    status = "success";
                }
            }

            // ── TEST 5: generate_fine ─────────────────────────────────────
            else if ("test_fine".equals(action)) {

                // Step 1 — Find and delete ALL previous test runs cleanly
                // First find all borrow IDs from previous test 5 runs
                ResultSet oldBorrows = conn.createStatement()
                    .executeQuery(
                        "SELECT Borrow_Id FROM book_info " +
                        "WHERE Member_Id=6 AND Book_Id=3 " +
                        "AND Borrow_Date='2024-01-01'");

                // Delete fines one by one for each old borrow
                while (oldBorrows.next()) {
                    int oldId = oldBorrows.getInt("Borrow_Id");
                    conn.createStatement().executeUpdate(
                        "DELETE FROM fine WHERE Borrow_Id=" + oldId);
                    conn.createStatement().executeUpdate(
                        "DELETE FROM book_info WHERE Borrow_Id=" + oldId);
                }

                // Step 2 — Restore book quantity
                conn.createStatement().executeUpdate(
                    "UPDATE book SET Quantity=3 WHERE Book_Id=3");

                // Step 3 — Count fines before
                ResultSet before = conn.createStatement()
                    .executeQuery("SELECT COUNT(*) AS cnt FROM fine");
                before.next();
                int finesBefore = before.getInt("cnt");

                // Step 4 — Insert fresh overdue borrow record
                conn.createStatement().executeUpdate(
                    "INSERT INTO book_info " +
                    "(Borrow_Date, Borrow_Time, Due_Date, Status, Librarian_Id, Member_Id, Book_Id) " +
                    "VALUES ('2024-01-01', '10:00:00', '2024-01-15', 'Issued', 1, 6, 3)");

                // Step 5 — Get the brand new Borrow_Id just inserted
                ResultSet newBorrow = conn.createStatement()
                    .executeQuery("SELECT LAST_INSERT_ID() AS id");
                newBorrow.next();
                int borrowId = newBorrow.getInt("id");

                // Step 6 — Return it — this fires generate_fine trigger automatically
                conn.createStatement().executeUpdate(
                    "UPDATE book_info SET Status='Returned' WHERE Borrow_Id=" + borrowId);

                // Step 7 — Count fines after
                ResultSet after = conn.createStatement()
                    .executeQuery("SELECT COUNT(*) AS cnt FROM fine");
                after.next();
                int finesAfter = after.getInt("cnt");

                // Step 8 — Show result
                if (finesAfter > finesBefore) {
                    ResultSet newFine = conn.createStatement()
                        .executeQuery(
                            "SELECT f.Amount, m.Name AS member_name " +
                            "FROM fine f " +
                            "JOIN book_info bi ON f.Borrow_Id = bi.Borrow_Id " +
                            "JOIN member m ON bi.Member_Id = m.Member_Id " +
                            "WHERE f.Borrow_Id=" + borrowId);
                    newFine.next();
                    result = "✅ TRIGGER FIRED: generate_fine → " +
                             "₹" + newFine.getDouble("Amount") +
                             " fine auto-created for " + newFine.getString("member_name") +
                             "! Fine table: " + finesBefore + " → " + finesAfter +
                             " record(s). No INSERT in Java — trigger did it!";
                    status = "success";
                } else {
                    result = "❌ Trigger did NOT fire — verify generate_fine " +
                             "exists in MySQL Workbench using: " +
                             "SELECT TRIGGER_NAME FROM information_schema.TRIGGERS " +
                             "WHERE TRIGGER_SCHEMA='SmartShelfDB'";
                    status = "fail";
                }
            }

            // ── RESET DATABASE ────────────────────────────────────────────
            else if ("reset".equals(action)) {
                conn.createStatement().executeUpdate("DELETE FROM fine");
                conn.createStatement().executeUpdate("DELETE FROM book_info");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=5 WHERE Book_Id=1");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=4 WHERE Book_Id=2");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=3 WHERE Book_Id=3");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=6 WHERE Book_Id=4");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=5 WHERE Book_Id=5");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=2 WHERE Book_Id=6");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=4 WHERE Book_Id=7");
                result = "🔄 Database reset! All book quantities restored, all borrows and fines cleared.";
                status = "info";
            }

        } catch (SQLException e) {
            result = "❌ Error: " + e.getMessage();
            status = "fail";
        }

        req.setAttribute("testResult", result);
        req.setAttribute("testStatus", status);
        req.setAttribute("lastAction", action);
        doGet(req, res);
    }
}
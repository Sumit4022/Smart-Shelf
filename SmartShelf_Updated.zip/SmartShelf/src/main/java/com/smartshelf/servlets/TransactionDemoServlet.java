package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/transactiondemo")
public class TransactionDemoServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        loadLiveData(req);
        req.getRequestDispatcher("/transactiondemo.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        String result = "";
        String status = "success";
        List<String> log = new ArrayList<>();

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false); // All transactions manual

            // ── T1: Issue a Book ──────────────────────────────────────────
            if ("t1_issue".equals(action)) {
                log.add("START TRANSACTION");

                ResultSet qBefore = conn.createStatement()
                    .executeQuery("SELECT Quantity FROM book WHERE Book_Id = 3");
                qBefore.next();
                int before = qBefore.getInt("Quantity");
                log.add("SELECT — Book 3 quantity before: " + before);

                conn.createStatement().executeUpdate(
                    "INSERT INTO book_info (Borrow_Date, Borrow_Time, Due_Date, Status, Librarian_Id, Member_Id, Book_Id) " +
                    "VALUES (CURDATE(), CURTIME(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Issued', 1, 6, 3)");
                log.add("INSERT INTO book_info — Member 6 borrows Book 3");

                conn.commit();
                log.add("COMMIT — transaction persisted");

                ResultSet qAfter = conn.createStatement()
                    .executeQuery("SELECT Quantity FROM book WHERE Book_Id = 3");
                qAfter.next();
                int after = qAfter.getInt("Quantity");
                log.add("VERIFY — Book 3 quantity after trigger: " + after);

                result = "T1 committed. Borrow record inserted for Member 6 / Book 3. " +
                         "Trigger reduce_quantity_on_issue fired: quantity " + before + " → " + after + ".";
                status = "success";
            }

            // ── T2: Return + Auto Fine ────────────────────────────────────
            else if ("t2_return".equals(action)) {
                log.add("START TRANSACTION");

                // Find an issued borrow or use last inserted for demo
                ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT Borrow_Id FROM book_info WHERE Status='Issued' ORDER BY Borrow_Id DESC LIMIT 1");
                if (!rs.next()) {
                    conn.rollback();
                    result = "No issued book found. Run T1 first to create an issued record.";
                    status = "warn";
                } else {
                    int borrowId = rs.getInt("Borrow_Id");
                    log.add("Found issued Borrow_Id = " + borrowId);

                    conn.createStatement().executeUpdate(
                        "UPDATE book_info SET Due_Date = '2024-01-01' WHERE Borrow_Id = " + borrowId);
                    log.add("UPDATE Due_Date → '2024-01-01' (simulate overdue)");

                    int finesBefore = countFines(conn);
                    log.add("Fine count before return: " + finesBefore);

                    conn.createStatement().executeUpdate(
                        "UPDATE book_info SET Status = 'Returned' WHERE Borrow_Id = " + borrowId);
                    log.add("UPDATE Status → 'Returned' — generate_fine trigger fires");

                    conn.commit();
                    log.add("COMMIT — return + fine atomically persisted");

                    int finesAfter = countFines(conn);
                    log.add("Fine count after: " + finesAfter);

                    result = "T2 committed. Borrow #" + borrowId + " returned (overdue). " +
                             "generate_fine trigger auto-inserted fine. Fine records: " + finesBefore + " → " + finesAfter + ".";
                    status = "success";
                }
            }

            // ── T3: Pay a Fine ────────────────────────────────────────────
            else if ("t3_payFine".equals(action)) {
                log.add("START TRANSACTION");

                ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT Fine_Id FROM fine WHERE Paid_Status='Unpaid' ORDER BY Fine_Id ASC LIMIT 1");
                if (!rs.next()) {
                    conn.rollback();
                    result = "No unpaid fine found. Run T2 to auto-generate a fine first.";
                    status = "warn";
                } else {
                    int fineId = rs.getInt("Fine_Id");
                    log.add("Found unpaid Fine_Id = " + fineId);

                    conn.createStatement().executeUpdate(
                        "UPDATE fine SET Paid_Status = 'Paid' WHERE Fine_Id = " + fineId + " AND Paid_Status = 'Unpaid'");
                    log.add("UPDATE fine SET Paid_Status='Paid' WHERE Fine_Id=" + fineId + " AND Paid_Status='Unpaid'");

                    ResultSet rowCount = conn.createStatement().executeQuery("SELECT ROW_COUNT() AS rc");
                    rowCount.next();
                    int rc = rowCount.getInt("rc");
                    log.add("ROW_COUNT() = " + rc + " (should be 1)");

                    conn.commit();
                    log.add("COMMIT — fine payment persisted");

                    result = "T3 committed. Fine #" + fineId + " marked Paid. ROW_COUNT = " + rc + ". " +
                             "Conditional WHERE prevents double-payment.";
                    status = "success";
                }
            }

            // ── T4: Add Book + Approve Reservation ───────────────────────
            else if ("t4_addBook".equals(action)) {
                log.add("START TRANSACTION");

                // Use timestamp to make ISBN unique on repeated demos
                String isbn = "ISBN_T4_" + System.currentTimeMillis() % 10000;
                conn.createStatement().executeUpdate(
                    "INSERT INTO book (Title, Author, Publisher, ISBN, Genre_Type, Librarian_Id, Quantity) " +
                    "VALUES ('Design Patterns', 'Gang of Four', 'Addison-Wesley', '" + isbn + "', 'Technology', 1, 3)");
                log.add("INSERT book 'Design Patterns' (ISBN: " + isbn + ", Qty: 3)");

                ResultSet newId = conn.createStatement().executeQuery("SELECT LAST_INSERT_ID() AS id");
                newId.next();
                int bookId = newId.getInt("id");
                log.add("LAST_INSERT_ID() = " + bookId);

                conn.createStatement().executeUpdate(
                    "INSERT INTO reservation (Reservation_Date, Status, Book_Id, Member_Id) " +
                    "VALUES (CURDATE(), 'Pending', " + bookId + ", 2)");
                log.add("INSERT reservation (Pending) for Member 2, Book " + bookId);

                conn.createStatement().executeUpdate(
                    "UPDATE reservation SET Status = 'Approved' WHERE Book_Id = " + bookId + " AND Member_Id = 2");
                log.add("UPDATE reservation → 'Approved'");

                conn.commit();
                log.add("COMMIT — book + reservation + approval all atomic");

                result = "T4 committed. Book '" + isbn + "' inserted (ID " + bookId + "). " +
                         "Reservation for Member 2 created and approved — all in one transaction.";
                status = "success";
            }

            // ── T5: Last-Copy Race Condition ──────────────────────────────
            else if ("t5_conflict".equals(action)) {
                log.add("Setup: UPDATE book SET Quantity=1 WHERE Book_Id=6 (last copy)");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity = 1 WHERE Book_Id = 6");
                conn.commit();
                log.add("Quantity set to 1 — committed");

                // Session A
                log.add("--- SESSION A ---");
                log.add("START TRANSACTION");
                conn.setAutoCommit(false);
                conn.createStatement().executeUpdate(
                    "INSERT INTO book_info (Borrow_Date, Borrow_Time, Due_Date, Status, Librarian_Id, Member_Id, Book_Id) " +
                    "VALUES (CURDATE(), CURTIME(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Issued', 2, 4, 6)");
                log.add("INSERT borrow record — Member 4, Book 6 (last copy)");
                conn.commit();
                log.add("COMMIT — Session A succeeded. Trigger fired: Qty now 0");

                ResultSet qty = conn.createStatement().executeQuery("SELECT Quantity FROM book WHERE Book_Id=6");
                qty.next();
                log.add("VERIFY — Book 6 Quantity = " + qty.getInt("Quantity"));

                // Session B
                log.add("--- SESSION B ---");
                log.add("START TRANSACTION");
                conn.setAutoCommit(false);
                try {
                    conn.createStatement().executeUpdate(
                        "INSERT INTO book_info (Borrow_Date, Borrow_Time, Due_Date, Status, Librarian_Id, Member_Id, Book_Id) " +
                        "VALUES (CURDATE(), CURTIME(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'Issued', 2, 5, 6)");
                    conn.commit();
                    log.add("INSERT succeeded — trigger did NOT fire (unexpected!)");
                    result = "T5 unexpected: Session B succeeded. Check check_book_availability trigger.";
                    status = "warn";
                } catch (SQLException triggerErr) {
                    conn.rollback();
                    log.add("TRIGGER BLOCKED: " + triggerErr.getMessage());
                    log.add("ROLLBACK — Session B aborted cleanly");
                    result = "T5 conflict resolved. Session A committed (last copy issued). " +
                             "Session B rolled back — trigger raised: \"" + triggerErr.getMessage() + "\".";
                    status = "conflict";
                }
            }

            // ── T6: Membership Book Limit ─────────────────────────────────
            else if ("t6_limit".equals(action)) {
                log.add("Setup: reset Member 2 borrows to 0");
                conn.createStatement().executeUpdate(
                    "UPDATE book_info SET Status='Returned' WHERE Member_Id=2 AND Status='Issued'");
                conn.commit();

                log.add("START TRANSACTION — issue book 1 to Member 2");
                conn.setAutoCommit(false);
                conn.createStatement().executeUpdate(
                    "INSERT INTO book_info (Borrow_Date,Borrow_Time,Due_Date,Status,Librarian_Id,Member_Id,Book_Id) " +
                    "VALUES (CURDATE(),CURTIME(),DATE_ADD(CURDATE(),INTERVAL 14 DAY),'Issued',1,2,1)");
                conn.commit();
                log.add("COMMIT — Borrow 1 (Book 1) for Member 2");

                conn.setAutoCommit(false);
                conn.createStatement().executeUpdate(
                    "INSERT INTO book_info (Borrow_Date,Borrow_Time,Due_Date,Status,Librarian_Id,Member_Id,Book_Id) " +
                    "VALUES (CURDATE(),CURTIME(),DATE_ADD(CURDATE(),INTERVAL 14 DAY),'Issued',1,2,2)");
                conn.commit();
                log.add("COMMIT — Borrow 2 (Book 2) for Member 2. Now at limit (2/2).");

                ResultSet cnt = conn.createStatement().executeQuery(
                    "SELECT COUNT(*) AS c FROM book_info WHERE Member_Id=2 AND Status='Issued'");
                cnt.next();
                log.add("Active borrow count = " + cnt.getInt("c") + " (at max)");

                log.add("--- Attempting 3rd borrow ---");
                conn.setAutoCommit(false);
                try {
                    conn.createStatement().executeUpdate(
                        "INSERT INTO book_info (Borrow_Date,Borrow_Time,Due_Date,Status,Librarian_Id,Member_Id,Book_Id) " +
                        "VALUES (CURDATE(),CURTIME(),DATE_ADD(CURDATE(),INTERVAL 14 DAY),'Issued',1,2,5)");
                    conn.commit();
                    result = "T6 unexpected: 3rd borrow succeeded. Check check_max_books trigger.";
                    status = "warn";
                } catch (SQLException triggerErr) {
                    conn.rollback();
                    log.add("TRIGGER BLOCKED: " + triggerErr.getMessage());
                    log.add("ROLLBACK — 3rd borrow aborted");
                    result = "T6 conflict resolved. Member 2 has 2 active borrows (at limit). " +
                             "3rd attempt rolled back — trigger raised: \"" + triggerErr.getMessage() + "\".";
                    status = "conflict";
                }
            }

            // ── T7: Concurrent Fine Payment ───────────────────────────────
            else if ("t7_dirtyWrite".equals(action)) {
                // Reset a fine to Unpaid
                ResultSet rs = conn.createStatement().executeQuery(
                    "SELECT Fine_Id FROM fine ORDER BY Fine_Id ASC LIMIT 1");
                if (!rs.next()) {
                    conn.rollback();
                    result = "No fine records found. Run T2 first to generate a fine.";
                    status = "warn";
                } else {
                    int fineId = rs.getInt("Fine_Id");
                    conn.createStatement().executeUpdate(
                        "UPDATE fine SET Paid_Status='Unpaid' WHERE Fine_Id=" + fineId);
                    conn.commit();
                    log.add("Setup: Fine #" + fineId + " reset to 'Unpaid'");

                    // Session A
                    log.add("--- SESSION A ---");
                    conn.setAutoCommit(false);
                    conn.createStatement().executeUpdate(
                        "UPDATE fine SET Paid_Status='Paid' WHERE Fine_Id=" + fineId + " AND Paid_Status='Unpaid'");
                    ResultSet rcA = conn.createStatement().executeQuery("SELECT ROW_COUNT() AS rc");
                    rcA.next();
                    int rowsA = rcA.getInt("rc");
                    conn.commit();
                    log.add("Session A UPDATE — ROW_COUNT = " + rowsA + " (1 = paid successfully)");

                    // Session B (late)
                    log.add("--- SESSION B (late arrival) ---");
                    conn.setAutoCommit(false);
                    conn.createStatement().executeUpdate(
                        "UPDATE fine SET Paid_Status='Paid' WHERE Fine_Id=" + fineId + " AND Paid_Status='Unpaid'");
                    ResultSet rcB = conn.createStatement().executeQuery("SELECT ROW_COUNT() AS rc");
                    rcB.next();
                    int rowsB = rcB.getInt("rc");
                    conn.commit();
                    log.add("Session B UPDATE — ROW_COUNT = " + rowsB + " (0 = no-op, already paid)");

                    result = "T7 safe. Session A: ROW_COUNT=" + rowsA + " (paid). " +
                             "Session B: ROW_COUNT=" + rowsB + " (no-op — conditional WHERE prevented lost update). " +
                             "Fine #" + fineId + " is Paid with no corruption.";
                    status = "success";
                }
            }

            // ── T8: Rollback — Duplicate Email ────────────────────────────
            else if ("t8_rollback".equals(action)) {
                log.add("START TRANSACTION");
                conn.setAutoCommit(false);
                try {
                    conn.createStatement().executeUpdate(
                        "INSERT INTO member (Name, Username, Password, Email_Id, Phone_Number, Membership_Type_Id, Membership_Start, Membership_Expiry) " +
                        "VALUES ('Rohit Duplicate', 'rohit_dup_" + System.currentTimeMillis() % 10000 + "', 'pass123', " +
                        "'rohit@mail.com', 9999999999, 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 180 DAY))");
                    conn.commit();
                    result = "T8 unexpected: insert succeeded. Check UNIQUE constraint on Email_Id.";
                    status = "warn";
                    log.add("INSERT succeeded — UNIQUE constraint not enforced (unexpected!)");
                } catch (SQLException e) {
                    conn.rollback();
                    log.add("INSERT failed — " + e.getMessage());
                    log.add("ROLLBACK — no partial data persisted");

                    ResultSet orig = conn.createStatement().executeQuery(
                        "SELECT Member_Id, Name FROM member WHERE Email_Id='rohit@mail.com'");
                    if (orig.next()) {
                        log.add("VERIFY — original member '" + orig.getString("Name") + "' (ID " + orig.getInt("Member_Id") + ") unchanged");
                    }
                    result = "T8 rolled back. UNIQUE constraint on Email_Id blocked duplicate. " +
                             "Error: \"" + e.getMessage() + "\". Original data intact.";
                    status = "rollback";
                }
            }

            // ── Full Reset ────────────────────────────────────────────────
            else if ("reset".equals(action)) {
                conn.setAutoCommit(true);
                conn.createStatement().executeUpdate("DELETE FROM fine");
                conn.createStatement().executeUpdate("DELETE FROM reservation WHERE Book_Id > 8");
                conn.createStatement().executeUpdate("DELETE FROM book_info");
                conn.createStatement().executeUpdate("DELETE FROM book WHERE Book_Id > 8");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=5 WHERE Book_Id=1");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=4 WHERE Book_Id=2");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=3 WHERE Book_Id=3");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=6 WHERE Book_Id=4");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=5 WHERE Book_Id=5");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=2 WHERE Book_Id=6");
                conn.createStatement().executeUpdate("UPDATE book SET Quantity=4 WHERE Book_Id=7");
                result = "Database reset. All borrows, fines, and test books cleared. Quantities restored.";
                status = "info";
                log.add("DELETE fine, DELETE book_info, RESTORE quantities");
            }

        } catch (SQLException e) {
            try { if (conn != null) conn.rollback(); } catch (SQLException ignored) {}
            result = "Error: " + e.getMessage();
            status = "fail";
            log.add("EXCEPTION: " + e.getMessage());
        } finally {
            try { if (conn != null) { conn.setAutoCommit(true); conn.close(); } } catch (SQLException ignored) {}
        }

        req.setAttribute("txResult", result);
        req.setAttribute("txStatus", status);
        req.setAttribute("txLog", log);
        req.setAttribute("lastAction", action);
        loadLiveData(req);
        req.getRequestDispatcher("/transactiondemo.jsp").forward(req, res);
    }

    private void loadLiveData(HttpServletRequest req) {
        try (Connection conn = DBConnection.getConnection()) {
            ResultSet books = conn.createStatement()
                .executeQuery("SELECT Book_Id, Title, Quantity FROM book ORDER BY Book_Id");
            req.setAttribute("books", DBConnection.toList(books));

            ResultSet members = conn.createStatement().executeQuery(
                "SELECT mb.Member_Id, mb.Name, m.Max_Book_Allowed, COUNT(bi.Borrow_Id) AS Current_Count " +
                "FROM member mb " +
                "JOIN membership m ON mb.Membership_Type_Id = m.Membership_Type_Id " +
                "LEFT JOIN book_info bi ON mb.Member_Id = bi.Member_Id AND bi.Status = 'Issued' " +
                "GROUP BY mb.Member_Id, mb.Name, m.Max_Book_Allowed");
            req.setAttribute("members", DBConnection.toList(members));

            ResultSet fines = conn.createStatement().executeQuery(
                "SELECT f.Fine_Id, m.Name AS member_name, f.Amount, f.Paid_Status " +
                "FROM fine f " +
                "JOIN book_info bi ON f.Borrow_Id = bi.Borrow_Id " +
                "JOIN member m ON bi.Member_Id = m.Member_Id " +
                "ORDER BY f.Fine_Id DESC");
            req.setAttribute("fines", DBConnection.toList(fines));

        } catch (SQLException e) {
            req.setAttribute("dbError", e.getMessage());
        }
    }

    private int countFines(Connection conn) throws SQLException {
        ResultSet rs = conn.createStatement().executeQuery("SELECT COUNT(*) AS c FROM fine");
        rs.next();
        return rs.getInt("c");
    }
}

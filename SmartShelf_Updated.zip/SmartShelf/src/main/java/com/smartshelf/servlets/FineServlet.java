package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

@WebServlet("/fines")
public class FineServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	        throws ServletException, IOException {
	    try (Connection conn = DBConnection.getConnection()) {

	        ResultSet rs = conn.createStatement().executeQuery(
	            "SELECT f.Fine_Id, f.Amount, f.Fine_Due_Date, f.Paid_Status, " +
	            "m.Name AS member_name, b.Title AS book_title " +
	            "FROM fine f " +
	            "JOIN book_info bi ON f.Borrow_Id = bi.Borrow_Id " +
	            "JOIN member m ON bi.Member_Id = m.Member_Id " +
	            "JOIN book b ON bi.Book_Id = b.Book_Id " +
	            "ORDER BY f.Paid_Status DESC");
	        req.setAttribute("fines", DBConnection.toList(rs));

	    } catch (SQLException e) {
	        req.setAttribute("error", e.getMessage());
	    }
	    req.getRequestDispatcher("/fines.jsp").forward(req, res);
	}

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        int fineId = Integer.parseInt(req.getParameter("fineId"));

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE fine SET Paid_Status='Paid' WHERE Fine_Id=?");
            ps.setInt(1, fineId);
            ps.executeUpdate();
            res.sendRedirect("fines?success=Fine+marked+as+paid");

        } catch (SQLException e) {
            res.sendRedirect("fines?error=" + e.getMessage());
        }
    }
}
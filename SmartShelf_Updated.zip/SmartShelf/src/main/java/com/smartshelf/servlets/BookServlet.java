package com.smartshelf.servlets;

import com.smartshelf.db.DBConnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;

@WebServlet("/books")
public class BookServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
	        throws ServletException, IOException {
	    try (Connection conn = DBConnection.getConnection()) {

	        ResultSet rs = conn.createStatement()
	            .executeQuery("SELECT * FROM book ORDER BY Genre_Type");
	        req.setAttribute("books", DBConnection.toList(rs));

	    } catch (SQLException e) {
	        req.setAttribute("error", e.getMessage());
	    }
	    req.getRequestDispatcher("/books.jsp").forward(req, res);
	}

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        try (Connection conn = DBConnection.getConnection()) {
            if ("add".equals(action)) {
                PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO book (Title, Author, Publisher, ISBN, Genre_Type, Librarian_Id, Quantity) " +
                    "VALUES (?, ?, ?, ?, ?, 1, ?)");
                ps.setString(1, req.getParameter("title"));
                ps.setString(2, req.getParameter("author"));
                ps.setString(3, req.getParameter("publisher"));
                ps.setString(4, req.getParameter("isbn"));
                ps.setString(5, req.getParameter("genre"));
                ps.setInt(6, Integer.parseInt(req.getParameter("qty")));
                ps.executeUpdate();
                res.sendRedirect("books?success=Book+added+successfully");

            } else if ("delete".equals(action)) {
                PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM book WHERE Book_Id=?");
                ps.setInt(1, Integer.parseInt(req.getParameter("bookId")));
                ps.executeUpdate();
                res.sendRedirect("books?success=Book+deleted+successfully");
            }

        } catch (SQLException e) {
            res.sendRedirect("books?error=" + e.getMessage());
        }
    }
}
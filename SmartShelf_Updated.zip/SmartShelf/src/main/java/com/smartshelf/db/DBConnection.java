package com.smartshelf.db;

import java.sql.*;
import java.util.*;

public class DBConnection {
    private static final String URL  = "jdbc:mysql://localhost:3306/SmartShelfDB";
    private static final String USER = "root";
    private static final String PASS = "1234"; // change this

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver not found", e);
        }
        return DriverManager.getConnection(URL, USER, PASS);
    }

    // Converts a ResultSet into a List of Maps so JSP c:forEach can iterate it
    public static List<Map<String, Object>> toList(ResultSet rs) throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        ResultSetMetaData meta = rs.getMetaData();
        int cols = meta.getColumnCount();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<>();
            for (int i = 1; i <= cols; i++) {
                row.put(meta.getColumnLabel(i), rs.getObject(i));
            }
            list.add(row);
        }
        return list;
    }
}